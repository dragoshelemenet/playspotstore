/* PlaySpotStore V33 — Progressive category-only search, price filters & sorting.
   All products remain in static, crawlable HTML. No network requests or new URLs.
*/
(() => {
  'use strict';
  const widget = document.getElementById('seo-filterbar');
  const grid = document.getElementById('seo-filter-grid');
  if (!widget || !grid || widget.dataset.ready === '1') return;
  widget.dataset.ready = '1';
  const ru = (document.documentElement.lang || '').toLowerCase().startsWith('ru');
  const lang = ru ? 'ru-RU' : 'ro-RO';
  const words = ru ? {
    count:(n,total) => `Найдено ${n} из ${total} товаров`,
    noPrices:'В этой категории цены уточняются при обращении. Доступны поиск по названию и сортировка.',
    all:'Все товары',
  } : {
    count:(n,total) => `${n} din ${total} produse`,
    noPrices:'Prețurile se confirmă prin contact în această categorie. Poți căuta după nume și sorta produsele.',
    all:'Toate produsele',
  };
  const $ = id => widget.querySelector('#' + id);
  const form=$('seo-filter-form'), query=$('seo-filter-query'), sort=$('seo-filter-sort');
  const toggle=$('seo-filter-toggle'), advanced=$('seo-filter-advanced');
  const min=$('seo-filter-min'), max=$('seo-filter-max');
  const known=$('seo-filter-known'), fresh=$('seo-filter-new');
  const reset=$('seo-filter-reset'), count=$('seo-filter-count');
  const badge=$('seo-filter-badge'), note=$('seo-filter-price-note');
  const empty=document.getElementById('seo-filter-empty');
  const chips=Array.from(widget.querySelectorAll('.seo-filter-quick button'));
  const cards=Array.from(grid.querySelectorAll(':scope > .seo-product-card'));
  if (!cards.length) return;
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('en-US').replace(/\s+/g,' ').trim();
  const listings=cards.map((card,index) => {
    const raw=card.getAttribute('data-price');
    const price=raw !== null && raw.trim() !== '' && Number.isFinite(Number(raw)) ? Number(raw) : null;
    const title=card.querySelector('h3')?.textContent?.trim() || '';
    return {card,index,title,name:normalize(title),price,recent:card.getAttribute('data-new')==='1'};
  });
  const havePrices=listings.some(x=>x.price !== null);
  const numberFormat=new Intl.NumberFormat(lang);
  function headerOffset() {
    const header=document.querySelector('.seo-header');
    if (header) widget.style.setProperty('--seo-header-live',Math.ceil(header.getBoundingClientRect().height)+'px');
  }
  headerOffset();
  if (typeof ResizeObserver==='function') {
    const head=document.querySelector('.seo-header');
    if (head) new ResizeObserver(headerOffset).observe(head);
  }
  window.addEventListener('resize',headerOffset,{passive:true});
  // A catalog with no listed prices must not pretend to have a price range.
  if (!havePrices) {
    min.disabled=true;max.disabled=true;known.disabled=true;
    for(const chip of chips) chip.disabled=true;
    for(const option of sort.options) if(option.value==='price-asc'||option.value==='price-desc')option.disabled=true;
    note.hidden=false;note.textContent=words.noPrices;
  }
  function updateChips() {
    for (const chip of chips) {
      const active=chip.dataset.min===min.value && chip.dataset.max===max.value;
      chip.setAttribute('aria-pressed',String(active));
    }
  }
  function order(list,type){
    const alphabet=(a,b)=>a.title.localeCompare(b.title,lang,{numeric:true,sensitivity:'base'});
    return list.sort((a,b)=>{
      if(type==='az') return alphabet(a,b) || a.index-b.index;
      if(type==='za') return alphabet(b,a) || a.index-b.index;
      if(type==='new') return Number(b.recent)-Number(a.recent) || a.index-b.index;
      if(type==='price-asc'||type==='price-desc') {
        if(a.price===null && b.price!==null)return 1;
        if(b.price===null && a.price!==null)return -1;
        if(a.price!==null && b.price!==null){
          const diff=type==='price-asc'?a.price-b.price:b.price-a.price;
          if(diff) return diff;
        }
      }
      return a.index-b.index;
    });
  }
  function apply() {
    const q=normalize(query.value);
    const minValue=min.value===''?null:Number(min.value);
    const maxValue=max.value===''?null:Number(max.value);
    const priceOnly=known.checked;
    const newOnly=fresh.checked;
    const selected=order(listings.slice(),sort.value);
    const filtered=selected.filter(item => {
      if(q && !item.name.includes(q)) return false;
      if(newOnly && !item.recent) return false;
      if((priceOnly || minValue!==null || maxValue!==null) && item.price===null) return false;
      if(minValue!==null && item.price < minValue) return false;
      if(maxValue!==null && item.price > maxValue) return false;
      return true;
    });
    const visible=new Set(filtered.map(item=>item.index));
    // Stable sort: reorder the same SEO links, never replace them with JS-rendered cards.
    const frag=document.createDocumentFragment();
    for(const item of selected){item.card.hidden=!visible.has(item.index);frag.appendChild(item.card);}
    grid.appendChild(frag);
    if(empty)empty.hidden=filtered.length!==0;
    count.textContent=words.count(numberFormat.format(filtered.length),numberFormat.format(listings.length));
    const countFilters=Number(!!q)+Number(min.value!=='')+Number(max.value!=='')+Number(priceOnly)+Number(newOnly)+Number(sort.value!=='default');
    badge.hidden=countFilters===0;badge.textContent=String(countFilters);
    updateChips();
    reset.disabled=countFilters===0;
  }
  form.addEventListener('submit',e=>e.preventDefault());
  form.addEventListener('input',e=>{
    if(e.target.matches('input'))apply();
  });
  sort.addEventListener('change',apply);
  toggle.addEventListener('click',()=>{
    advanced.hidden=!advanced.hidden;
    toggle.setAttribute('aria-expanded',String(!advanced.hidden));
    widget.classList.toggle('seo-filter-open',!advanced.hidden);
    headerOffset();
  });
  chips.forEach(chip=>chip.addEventListener('click',()=>{
    if(chip.disabled)return;
    const wasActive=chip.getAttribute('aria-pressed')==='true';
    min.value=wasActive?'':chip.dataset.min;
    max.value=wasActive?'':chip.dataset.max;
    apply();
  }));
  form.addEventListener('reset',()=>requestAnimationFrame(()=>{
    min.value='';max.value='';apply();
  }));
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape' && !advanced.hidden && !widget.contains(document.activeElement)) {
      advanced.hidden=true;widget.classList.remove('seo-filter-open');toggle.setAttribute('aria-expanded','false');
    }
  });
  widget.hidden=false;
  apply();
})();
