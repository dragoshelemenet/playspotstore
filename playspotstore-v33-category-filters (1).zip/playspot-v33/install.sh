#!/usr/bin/env bash
set -euo pipefail
if [[ ! -d .git || ! -f index.html || ! -f ru.html || ! -f playspot-v29/generate.py || ! -f playspot-v32/human_sitemap.py ]]; then
  echo 'ERROR: Run from PlaySpotStore repository root after installing V32.' >&2
  exit 1
fi
git pull --ff-only origin main
python3 playspot-v33/patch.py --root .
python3 playspot-v29/generate.py --root .
python3 playspot-v29/validate.py --root .
python3 playspot-v32/validate.py --root .
python3 playspot-v33/validate.py --root .
git add -A playspot-v33/ playspot-v29/generate.py seo/ categorii/ ru/categorii/ produse/ ru/produse/ sitemap.xml sitemap.html ru/sitemap.html robots.txt index.html ru.html
if git diff --cached --quiet; then
  echo 'V33 is up to date: nothing to commit.'
else
  git commit -m 'V33: category search, real price filters and sort (RO/RU)'
  git push origin main
fi
echo 'SUCCESS: V33 category filters are published.'
