#!/usr/bin/env python3
"""PlaySpotStore V33: enhance *static SEO category pages* with progressive filters.
Does not touch products, sitemap URLs, canonical tags, or backend visitor counter.
"""
from pathlib import Path
import argparse
import re

INSERT_FUNCTION = '''
def seo_filter_toolbar(cat, lang):
    ru = lang == 'ru'
    words = ({
        'search':'Поиск в этой категории','placeholder':'Название игры или товара...',
        'sort':'Сортировка', 'default':'По порядку', 'az':'Название А–Я', 'za':'Название Я–А',
        'low':'Цена: сначала дешёвые', 'high':'Цена: сначала дорогие', 'newfirst':'Новинки сначала',
        'filters':'Фильтры', 'reset':'Сброс', 'price':'Цена (MDL)', 'min':'От', 'max':'До',
        'quick':'Быстрая цена', 'under':'До 300', 'mid':'300–500', 'upper':'500–800', 'over':'От 800',
        'known':'Только с указанной ценой', 'recent':'Только новинки',
        'switch':'Другие категории', 'results':'Результаты поиска',
        'empty':'В этой категории ничего не найдено. Измените запрос или фильтры.',
    } if ru else {
        'search':'Caută în această categorie','placeholder':'Caută după numele jocului...',
        'sort':'Sortează', 'default':'Ordinea din catalog', 'az':'Nume A–Z', 'za':'Nume Z–A',
        'low':'Preț: crescător', 'high':'Preț: descrescător', 'newfirst':'Produse noi primele',
        'filters':'Filtre', 'reset':'Resetează', 'price':'Preț (MDL)', 'min':'De la', 'max':'Până la',
        'quick':'Preț rapid', 'under':'Sub 300', 'mid':'300–500', 'upper':'500–800', 'over':'Peste 800',
        'known':'Doar cu preț afișat', 'recent':'Doar produse noi',
        'switch':'Alte categorii', 'results':'Rezultatele căutării',
        'empty':'Nu am găsit produse în această categorie. Modifică filtrele sau căutarea.',
    })
    # Existing category links are ordinary anchors: switching never mixes inventories.
    choices = ''.join('<a href="/'+category_path(c,lang)+'"'+(' aria-current="page"' if c==cat else '')+'>'+esc(CAT_RU[c] if ru else CAT_RO[c])+'</a>' for c in CATEGORIES)
    return f\'''<section class="seo-filterbar" id="seo-filterbar" data-category="{esc(cat)}" aria-label="{esc(words['search'])}" hidden>
<form id="seo-filter-form" role="search" autocomplete="off">
<div class="seo-filter-primary">
<label class="seo-filter-query"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.7" cy="10.7" r="6.7"/><path d="m16 16 5 5"/></svg><span class="seo-filter-sr">{esc(words['search'])}</span><input id="seo-filter-query" type="search" placeholder="{esc(words['placeholder'])}" aria-label="{esc(words['search'])}" enterkeyhint="search"></label>
<label class="seo-filter-sort"><span class="seo-filter-sr">{esc(words['sort'])}</span><select id="seo-filter-sort" aria-label="{esc(words['sort'])}"><option value="default">{esc(words['default'])}</option><option value="az">{esc(words['az'])}</option><option value="za">{esc(words['za'])}</option><option value="price-asc">{esc(words['low'])}</option><option value="price-desc">{esc(words['high'])}</option><option value="new">{esc(words['newfirst'])}</option></select></label>
<button class="seo-filter-toggle" id="seo-filter-toggle" type="button" aria-expanded="false" aria-controls="seo-filter-advanced"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="#0a2529"/><circle cx="15" cy="17" r="2" fill="#0a2529"/></svg>{esc(words['filters'])}<span id="seo-filter-badge" hidden></span></button>
<button class="seo-filter-reset" id="seo-filter-reset" type="reset">{esc(words['reset'])}</button>
</div>
<div class="seo-filter-advanced" id="seo-filter-advanced" hidden>
<fieldset class="seo-filter-pricerange"><legend>{esc(words['price'])}</legend><label>{esc(words['min'])}<input id="seo-filter-min" type="number" min="0" step="1" inputmode="numeric" placeholder="0" aria-label="{esc(words['min'])} MDL"></label><label>{esc(words['max'])}<input id="seo-filter-max" type="number" min="0" step="1" inputmode="numeric" placeholder="∞" aria-label="{esc(words['max'])} MDL"></label></fieldset>
<div class="seo-filter-quick" role="group" aria-label="{esc(words['quick'])}"><span>{esc(words['quick'])}</span><button type="button" data-min="" data-max="299">{esc(words['under'])}</button><button type="button" data-min="300" data-max="500">{esc(words['mid'])}</button><button type="button" data-min="500" data-max="800">{esc(words['upper'])}</button><button type="button" data-min="800" data-max="">{esc(words['over'])}</button></div>
<div class="seo-filter-switches"><label><input id="seo-filter-known" type="checkbox">{esc(words['known'])}</label><label><input id="seo-filter-new" type="checkbox">{esc(words['recent'])}</label></div>
<p class="seo-filter-price-note" id="seo-filter-price-note" hidden></p>
</div>
<div class="seo-filter-meta"><p class="seo-filter-count" id="seo-filter-count" role="status" aria-live="polite" aria-atomic="true"></p><nav class="seo-filter-catnav" aria-label="{esc(words['switch'])}">{choices}</nav></div>
</form></section><p class="seo-filter-empty" id="seo-filter-empty" hidden>{esc(words['empty'])}</p>\'''

'''

def exactly_once(s, a, b, what):
    if s.count(a) != 1:
        raise RuntimeError(f'V33 cannot safely find unique {what}: found {s.count(a)}')
    return s.replace(a,b,1)

def patch(root):
    gen=root/'playspot-v29'/'generate.py'
    if not gen.is_file() or not (root/'seo'/'site.css').exists():
        raise SystemExit('V29 SEO catalog required. Run from PlaySpotStore repository root.')
    src=gen.read_text('utf-8')
    if 'def seo_filter_toolbar(cat, lang):' not in src:
        src=exactly_once(src,'def category_html(cat,lang,products,ro_products):',INSERT_FUNCTION+'def category_html(cat,lang,products,ro_products):','category function')
    if 'data-price="{esc(card_price)}"' not in src:
        needle="    b='<span class=\"seo-new\">'+esc(t['new'])+'</span>' if it.get('new_arrival')=='yes' else ''\n    return f'''<article class=\"seo-product-card\"><a"
        rep="    b='<span class=\"seo-new\">'+esc(t['new'])+'</span>' if it.get('new_arrival')=='yes' else ''\n    number=price_value(it.get('price'))\n    card_price=f'{number:g}' if number is not None else ''\n    fresh='1' if it.get('new_arrival')=='yes' else '0'\n    return f'''<article class=\"seo-product-card\" data-price=\"{esc(card_price)}\" data-new=\"{fresh}\"><a"
        src=exactly_once(src,needle,rep,'SEO product card markup')
    if 'toolbar=seo_filter_toolbar(cat,lang)' not in src:
        src=exactly_once(src,"    cards=''.join(product_card(p,cat,lang,ro) for p,ro in zip(products,ro_products))", "    cards=''.join(product_card(p,cat,lang,ro) for p,ro in zip(products,ro_products))\n    toolbar=seo_filter_toolbar(cat,lang)\n    page=page.replace('</head>','<link rel=\"stylesheet\" href=\"/seo/filter.css?v=20261109-v33\">\\n</head>',1)", 'category page head/cards')
    if '<div class="seo-grid">{cards}</div></section>' in src:
        src=exactly_once(src,'<div class="seo-grid">{cards}</div></section>','{toolbar}<div class="seo-grid" id="seo-filter-grid">{cards}</div></section>','SEO category grid')
    if '{footer(lang)}<script defer src="/seo/filter.js?v=20261109-v33"></script></body></html>' not in src:
        before,after=src.split('def product_html(',1)
        before=exactly_once(before,'{footer(lang)}</body></html>\'\'\'','{footer(lang)}<script defer src="/seo/filter.js?v=20261109-v33"></script></body></html>\'\'\'','category page script')
        src=before+'def product_html('+after
    anchor="    shutil.copyfile(Path(__file__).with_name('home.css'),seo_dir/'home.css')"
    if "seo_dir/'filter.css'" not in src:
        src=exactly_once(src,anchor,anchor+"\n    shutil.copyfile(root/'playspot-v33'/'filter.css',seo_dir/'filter.css')\n    shutil.copyfile(root/'playspot-v33'/'filter.js',seo_dir/'filter.js')",'generator CSS sync')
    gen.write_text(src,'utf-8')
    print('V33 generator patched safely. Re-running product generation will preserve search/filter UI.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.')
    patch(Path(ap.parse_args().root).resolve())
