PlaySpotStore V33 — Category Search & Filters (RO/RU)
====================================================
Installer (run at repository root after uploading ZIP):
git pull --ff-only origin main && unzip -o playspotstore-v33-category-filters.zip -d . && bash playspot-v33/install.sh

Includes:
- Live in-category text search (accent insensitive)
- Real min/max MDL price filters and quick price bands
- Sort catalog order, name A-Z/Z-A, low/high price, new first
- Only with listed prices / new products
- Category shortcuts, reset, result count, no-results state
- No fake prices: price filters disabled when a category has no listed prices
- Works on RO + RU category pages; existing HTML product links remain in source for SEO
- No change to sitemap URLs, backend visitor counter, Spin & Win, or individual product pages beyond card data attributes
- Future inventory refresh: python3 playspot-v29/generate.py --root .

Technical: Uses only client-side progressive enhancement, no external JS packages or HTTP requests. Search affects only products on the current category page.
