#!/usr/bin/env python3
"""V33 regression checks: generated filters, real price fields, crawlability."""
from pathlib import Path
import argparse, json, importlib.util, xml.etree.ElementTree as ET
from html.parser import HTMLParser

class CatalogParser(HTMLParser):
    def __init__(self):
        super().__init__();self.cards=[];self.links=0;self.scripts=[];self.styles=[];self.ids=set();self.canon=[];self.current_product=False
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.add(a['id'])
        if tag=='article' and 'seo-product-card' in a.get('class','').split():self.cards.append(a)
        if tag=='a' and a.get('href','').startswith(('/produse/','/ru/produse/')):self.links+=1
        if tag=='link' and a.get('rel')=='canonical':self.canon.append(a.get('href'))
        if tag=='link' and '/seo/filter.css' in a.get('href',''):self.styles.append(a['href'])
        if tag=='script' and '/seo/filter.js' in a.get('src',''):self.scripts.append(a['src'])

def check(root):
    gen=root/'playspot-v29'/'generate.py'
    assert gen.exists() and (root/'seo/filter.js').exists() and (root/'seo/filter.css').exists()
    src=gen.read_text()
    assert src.count('def seo_filter_toolbar(cat, lang)')==1
    assert src.count("seo_dir/'filter.js'")==1
    for cat in ('ps2','ps4','ps5','nintendo','xbox','consoles','accessories'):
        datafile='consoles' if cat=='consoles' else cat
        for lang in ('ro','ru'):
            entries=json.loads((root/'data'/(datafile+('_ru' if lang=='ru' else '')+'.json')).read_text())
            path=root/('ru/' if lang=='ru' else '')/'categorii'/(cat+'.html')
            assert path.exists(),path
            parser=CatalogParser();parser.feed(path.read_text())
            assert len(parser.cards)==len(entries),(path,'card mismatch',len(parser.cards),len(entries))
            assert parser.links==len(entries),(path,'crawlable links',parser.links,len(entries))
            assert len(parser.styles)==len(parser.scripts)==1,(path,parser.styles,parser.scripts)
            assert {'seo-filterbar','seo-filter-query','seo-filter-min','seo-filter-max','seo-filter-sort','seo-filter-count','seo-filter-grid','seo-filter-empty'}.issubset(parser.ids),path
            for card,item in zip(parser.cards,entries):
                price=str(item.get('price','')).strip()
                import re
                match=re.fullmatch(r'([\d,.]+)\s+MDL',price,re.I)
                expected=float(match.group(1).replace(',','')) if match else None
                actual=card['data-price']
                assert (actual=='' if expected is None else float(actual)==expected),(path,item['id'],actual,price)
                assert card['data-new']==('1' if item.get('new_arrival')=='yes' else '0'),(path,item['id'])
    assert 'xml-stylesheet' not in (root/'sitemap.xml').read_text()
    assert 'Sitemap: https://playspotstore.online/sitemap.xml' in (root/'robots.txt').read_text()
    print('✅ V33: 14 category pages, accurate numeric data, 1 stylesheet & script per category, all product links crawlable')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.')
    check(Path(ap.parse_args().root).resolve())
