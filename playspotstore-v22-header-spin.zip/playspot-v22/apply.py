#!/usr/bin/env python3
"""PlaySpotStore V22: install the mobile header Spin & Win CTA idempotently."""
from pathlib import Path
import re,sys
root=Path.cwd()
files=('index.html','ru.html')
for file in files:
    path=root/file
    if not path.exists():
        raise SystemExit(f'ERROR: Run the installer from the repository root. Missing {file}')
    text=path.read_text(encoding='utf-8')
    if 'playspot-v14.js' not in text or 'playspot-v16.js' not in text:
        raise SystemExit(f'ERROR: Spin & Win base scripts are missing from {file}; install V14-V21 first.')
    before=text
    if 'class="p22-header-spin"' not in text:
        # Insert between the existing brand and nav (not before a random page link).
        h=text.index('<header>');a=text.index('<a class="logo"',h);end=text.index('</a>',a)+len('</a>')
        if not ('<nav' in text[end:end+90]):
            raise SystemExit(f'ERROR: Unexpected header structure in {file}; not modifying.')
        alt=('Открыть колесо Spin & Win' if file=='ru.html' else 'Deschide roata Spin & Win')
        button=(f'\n<button class="p22-header-spin" type="button" aria-label="{alt}" '
                f'aria-haspopup="dialog" aria-controls="p14-spin-overlay">'
                '<img src="media/spin-win-header-v22.webp" width="760" height="168" alt="" aria-hidden="true" decoding="async">'
                '</button>')
        text=text[:end]+button+text[end:]
    if 'playspot-v22.css' not in text:
        if '</head>' not in text:raise SystemExit('ERROR: </head> not found')
        text=text.replace('</head>','  <link rel="stylesheet" href="playspot-v22.css?v=20261108-v22">\n</head>',1)
    if 'playspot-v22.js' not in text:
        if '</body>' not in text:raise SystemExit('ERROR: </body> not found')
        text=text.replace('</body>','  <script defer src="playspot-v22.js?v=20261108-v22"></script>\n</body>',1)
    path.write_text(text,encoding='utf-8')
    print(f'{file}: '+('updated' if text!=before else 'already installed'))
