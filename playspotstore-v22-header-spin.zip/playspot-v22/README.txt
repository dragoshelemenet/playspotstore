PlaySpotStore V22: mobile header Spin & Win button using exact supplied reference image.

From repository root:
git pull --ff-only origin main && unzip -o playspotstore-v22-header-spin.zip -d . && bash playspot-v22/install.sh

Visible on mobile/tablet <= 950px, centered between logo and hamburger. Clicking triggers the existing Spin & Win wheel. Does not change 3 spins/day or floating bottom bar. Applies to RO and RU.
