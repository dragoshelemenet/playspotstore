#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [ "$(git branch --show-current)" != "main" ]; then
  echo 'ERROR: Switch to branch main before installing.' >&2; exit 1
fi
git pull --ff-only origin main
python3 playspot-v22/apply.py
install -m 644 playspot-v22/playspot-v22.css ./playspot-v22.css
install -m 644 playspot-v22/playspot-v22.js ./playspot-v22.js
mkdir -p media
install -m 644 playspot-v22/media/spin-win-header-v22.webp ./media/spin-win-header-v22.webp
git add index.html ru.html playspot-v22.css playspot-v22.js media/spin-win-header-v22.webp
if git diff --cached --quiet; then
  echo 'V22 is already installed; no commit needed.'
else
  git commit -m 'V22: add mobile header Spin & Win button from reference'
  git push origin main
fi
echo 'SUCCESS: PlaySpotStore V22 mobile header Spin & Win.'
