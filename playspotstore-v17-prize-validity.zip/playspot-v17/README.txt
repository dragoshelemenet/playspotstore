PlaySpotStore V17 — PRIZE EXPIRY, PUBLIC PROMO COPY

Summary
- Public promo text no longer says that the campaign will definitely renew.
- The spin bar still shows the current countdown in days and runs according to the existing internal 30-day cycles.
- The won prize visibly says "Valabil până la: <date>" (Russian: "Действителен до: <date>").
- WhatsApp claim text includes that exact expiration date and 30-day validity.
- Downloadable PNG highlights the 30-day expiration date in a readable green strip.
- All changes are applied in Romanian and Russian; daily spin count unchanged.

INSTALL (from repository root after uploading ZIP there)
  git pull --ff-only origin main && unzip -o playspotstore-v17-prize-validity.zip -d . && bash playspot-v17/install.sh

Reminder: limits and prize references remain browser-side only; manual store validation is necessary.
