#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
[[ -f index.html && -f ru.html && -f playspot-v14.js && -f playspot-v16.js ]] || { echo 'ERROR: Run in the PlaySpotStore repository root.' >&2; exit 1; }
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'ERROR: Tracked files have uncommitted changes; commit or stash first.' >&2
  git status --short
  exit 1
fi
git pull --ff-only origin main
python3 playspot-v17/install.py
if command -v node >/dev/null 2>&1; then
  node --check playspot-v14.js
  node --check playspot-v16.js
fi
git add index.html ru.html playspot-v14.js playspot-v16.js
if git diff --cached --quiet; then echo 'V17 already installed'; exit 0; fi
git -c user.name='PlaySpotStore' -c user.email='playspotstore@users.noreply.github.com' commit -m 'Clarify discount code expiry without promising promotion renewal'
git push origin HEAD:main
echo 'SUCCESS — V17 published. Refresh the site to see the changes.'
