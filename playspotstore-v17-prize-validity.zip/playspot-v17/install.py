#!/usr/bin/env python3
"""Small, idempotent V17 patch: public promo copy + expiry on prizes/receipts."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent

def replace_required(text, before, after, name):
    if before in text:
        count=text.count(before)
        if count!=1:
            raise ValueError(f'{name}: expected one occurrence, found {count}: {before[:75]}')
        return text.replace(before, after)
    if after in text:
        return text  # idempotent
    raise ValueError(f'{name}: source template changed; refusing to patch automatically: {before[:95]}')

def patch(path, substitutions):
    f=ROOT/path
    if not f.exists(): raise FileNotFoundError(f'Required file not found: {path}')
    s=f.read_text(encoding='utf-8')
    for before,after in substitutions:
        s=replace_required(s,before,after,path)
    f.write_text(s,encoding='utf-8')
    print('Updated',path)

patch('playspot-v16.js', [
    ("note: 'Предложение обновляется каждые 30 дней. Следующее обновление:'",
     "note: 'Акция ограничена по времени. Каждый полученный код действителен 30 дней с момента выигрыша.'"),
    ("note: 'Promoția se reînnoiește la fiecare 30 de zile. Următoarea reînnoire:'",
     "note: 'Promoție cu durată limitată. Fiecare cod câștigat este valabil 30 de zile de la rotire.'"),
    ("note.textContent = words.note + ' ' + endDate + '. ' + words.prize;",
     "note.textContent = words.note;"),
])

patch('playspot-v14.js', [
    ("(ru?'Код действителен 30 дней, до ':'Cod valabil 30 zile, până la ')+printDate(expires);",
     "(ru?'Действителен до: ':'Valabil până la: ')+printDate(expires);"),
    ("(ru?'Код действует 30 дней, до ':'Codul este valabil 30 de zile, până la ')+printDate(prizeExpiryTime(win))+'.');",
     "(ru?'Действителен до: ':'Valabil până la: ')+printDate(prizeExpiryTime(win))+(ru?' (30 дней с момента выигрыша).':' (30 de zile de la câștig).'));"),
    ("c.fillStyle='#afc9cb';c.font='500 20px Arial';c.fillText((ru?'Код действует до: ':'Cod valabil până la: ')+printDate(prizeExpiryTime(win)),95,548);",
     "c.fillStyle='rgba(57,151,119,.27)';drawRound(c,87,517,888,44,12);c.fill();\n    c.fillStyle='#adffda';c.font='700 27px Arial';c.fillText((ru?'Действителен до: ':'Valabil până la: ')+printDate(prizeExpiryTime(win)),102,547);"),
])

for name in ('index.html','ru.html'):
    patch(name,[
        ('playspot-v14.js?v=20261108-v16','playspot-v14.js?v=20261108-v17'),
        ('playspot-v16.js?v=20261108-v16','playspot-v16.js?v=20261108-v17'),
    ])

assert 'se reînnoiește' not in (ROOT/'playspot-v16.js').read_text()
assert 'Предложение обновляется' not in (ROOT/'playspot-v16.js').read_text()
assert "Valabil până la: ')+printDate(prizeExpiryTime(win))" in (ROOT/'playspot-v14.js').read_text()
print('V17 installed: no public renewal promise; win and PNG show explicit expiration date.')
