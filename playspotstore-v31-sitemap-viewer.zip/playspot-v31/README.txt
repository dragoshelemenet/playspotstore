PlaySpotStore V31 — Human-readable sitemap
=========================================
What changes:
 - Adds sitemap.xsl, a readable grouped view of the 574-URL sitemap in browsers with XSLT support.
 - Inserts an XML stylesheet processing instruction in sitemap.xml.
 - Updates V29 generator so future regenerate does not remove this processing instruction.
 - Does NOT convert sitemap XML into HTML. Robots.txt, URLs and hreflang remain unchanged.

Install from repo root:
 git pull --ff-only origin main && unzip -o playspotstore-v31-sitemap-viewer.zip -d . && bash playspot-v31/install.sh

Some browsers / XML viewers do not execute XSLT and will still show raw text. This is a browser viewer issue, not an indexing problem.
