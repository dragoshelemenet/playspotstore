#!/usr/bin/env python3
"""V31: make the existing Google sitemap human-readable, without changing its URLs."""
from pathlib import Path
import argparse
import re
import shutil
import xml.etree.ElementTree as ET

XML_PI = '<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>'
GEN_ANCHOR = "    ET.ElementTree(rootxml).write(root/'sitemap.xml',encoding='utf-8',xml_declaration=True)"
GEN_INSERT = """    # V31: Attach a human-friendly XSL view while retaining the real XML sitemap.
    xml_file = root/'sitemap.xml'
    xml_text = xml_file.read_text(encoding='utf-8')
    xml_text = re.sub(r'<\\?xml-stylesheet\\b[^>]*\\?>\\s*', '', xml_text)
    xml_text = xml_text.replace('?>', '?>\\n<?xml-stylesheet type=\\"text/xsl\\" href=\\"/sitemap.xsl\\"?>', 1)
    xml_file.write_text(xml_text, encoding='utf-8')
"""


def patch(root):
    root = root.resolve()
    if not (root/'index.html').is_file() or not (root/'playspot-v29/generate.py').is_file():
        raise RuntimeError('Run from the repository root after V29/V30 is installed.')
    genpath=root/'playspot-v29/generate.py'
    source=genpath.read_text(encoding='utf-8')
    if '# V31: Attach a human-friendly XSL view' not in source:
        if source.count(GEN_ANCHOR)!=1:
            raise RuntimeError('Could not find the V29 sitemap write command; not modifying the generator.')
        source=source.replace(GEN_ANCHOR,GEN_ANCHOR+'\n'+GEN_INSERT,1)
        genpath.write_text(source,encoding='utf-8')
    shutil.copyfile(Path(__file__).with_name('sitemap.xsl'), root/'sitemap.xsl')
    xmlpath=root/'sitemap.xml'
    xml=xmlpath.read_text(encoding='utf-8')
    if not re.match(r'^<\?xml\b[^>]*\?>',xml):
        raise RuntimeError('Existing sitemap.xml has no XML declaration; refusing to replace it.')
    xml=re.sub(r'<\?xml-stylesheet\b[^>]*\?>\s*','',xml)
    xml=re.sub(r'^(<\?xml\b[^>]*\?>)',r'\1\n'+XML_PI,xml,count=1)
    xmlpath.write_text(xml,encoding='utf-8')
    parsed=ET.parse(xmlpath)
    ns='{http://www.sitemaps.org/schemas/sitemap/0.9}'
    assert parsed.getroot().tag==ns+'urlset','Not an XML sitemap'
    count=len(parsed.findall('.//'+ns+'url'))
    assert count>0,'The sitemap is empty'
    assert XML_PI in xml,'The sitemap viewer is missing'
    print(f'✅ Valid XML sitemap with {count} URLs, viewer at /sitemap.xsl')
    print('✅ Future regeneration retains the XSL viewer')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',default='.')
    patch(Path(parser.parse_args().root))
