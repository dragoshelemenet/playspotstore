#!/usr/bin/env python3
"""Targeted RO/RU footer patch; no catalog or order/contact action changes."""
from pathlib import Path
import re

root = Path.cwd()
package = Path(__file__).parent
pages = [('index.html', False), ('ru.html', True)]


def make_markup(ru: bool) -> str:
    subtitle = 'Игры, консоли и аксессуары для игроков в Молдове.' if ru else 'Jocuri, console și accesorii pentru gamerii din Moldova.'
    links = [
        ('Главная' if ru else 'Acasă', '#acasa'),
        ('Новинки' if ru else 'Produse noi', '#produse-noi'),
        ('GTA 6', '#gta6'),
        ('Контакты' if ru else 'Contact', '#contact'),
    ]
    nav = ''.join(f'<a href="{url}">{label}</a>' for label, url in links)
    label = 'Метки' if ru else 'Etichete'
    copyright = 'Все права защищены.' if ru else 'Toate drepturile rezervate.'
    prompt = 'Поиск по меткам и городам. Первые результаты появляются ниже.' if ru else 'Caută după localitate sau tip de produs. Sunt afișate primele rezultate.'
    placeholder = 'Поиск по меткам...' if ru else 'Caută etichete...'
    close = 'Закрыть' if ru else 'Închide'
    return f'''</section>
<footer class="p8-footer" aria-label="{ 'Нижняя навигация' if ru else 'Informații despre PlaySpotStore'}">
  <div class="p8-wrap">
    <div class="p8-main">
      <div class="p8-brand">
        <img src="media/play-spot-logo-v4.webp" width="67" height="67" alt="" loading="lazy" decoding="async">
        <div><strong>PlaySpotStore</strong><p>{subtitle}</p></div>
      </div>
      <nav class="p8-links" aria-label="{'Ссылки внизу сайта' if ru else 'Navigare rapidă'}">{nav}</nav>
    </div>
    <div class="p8-bottom">
      <small>© 2026 PlaySpotStore · Joacă. Descoperă. Câștigă. · {copyright}</small>
      <button id="p8-tags-open" class="p8-tag-trigger" type="button" aria-haspopup="dialog" aria-controls="p8-tags-dialog" aria-label="{label}" title="{label}">
        <svg aria-hidden="true" viewBox="0 0 24 24"><path d="M3.5 11V5a1.5 1.5 0 0 1 1.5-1.5h6L21 13.5l-7.5 7.5L3.5 11Z"/><circle cx="8" cy="8" r="1.3"/></svg>
      </button>
    </div>
  </div>
</footer>
<dialog class="p8-tags-dialog" id="p8-tags-dialog" aria-labelledby="p8-tags-title">
  <div class="p8-tags-content">
    <div class="p8-dialog-head"><h2 id="p8-tags-title">{label}</h2><button type="button" class="p8-dialog-close" id="p8-tags-close" aria-label="{close}">×</button></div>
    <p class="p8-dialog-subtitle">{prompt}</p>
    <input class="p8-search" type="search" id="p8-tags-search" placeholder="{placeholder}" autocomplete="off" aria-label="{placeholder}">
    <div class="p8-tags-results" id="p8-tags-results" aria-live="polite"></div>
  </div>
</dialog>'''


def transform(page: str, ru: bool) -> str:
    # Match the old footer plus the closing contact section; move the new footer
    # outside contact so its background can flow smoothly into the page.
    expression = re.compile(r'<footer(?:\s[^>]*)?>[\s\S]*?</footer>\s*</section>', re.IGNORECASE)
    matches = list(expression.finditer(page))
    if 'class="p8-footer"' in page:
        raise RuntimeError('V8 already installed; nothing will be rewritten')
    if len(matches) != 1:
        raise RuntimeError(f'Expected one footer/contact match, found {len(matches)}')
    page = expression.sub(lambda _: make_markup(ru), page, count=1)
    if page.count('id="p8-tags-open"') != 1 or page.count('id="p8-tags-dialog"') != 1:
        raise RuntimeError('Footer structure validation failed')
    # CSS after prior layers; no duplicate link if re-run.
    link = '<link rel="stylesheet" href="playspot-v8.css?v=20261105">'
    if link not in page:
        if page.count('</head>') != 1:
            raise RuntimeError('Unexpected HTML head')
        page = page.replace('</head>', f'  {link}\n</head>', 1)
    script = '<script defer src="playspot-v8.js?v=20261105"></script>'
    if script not in page:
        if page.count('</body>') != 1:
            raise RuntimeError('Unexpected HTML body')
        page = page.replace('</body>', f'  {script}\n</body>', 1)
    if 'async function loadTags()' in page or 'id="tag-count"' in page or 'id="tags"' in page:
        raise RuntimeError('Legacy tags code unexpectedly remained')
    if '<section class="contact" id="contact">' not in page and '<section class="contact" id="contact"' not in page:
        raise RuntimeError('Contact section not found; refusing to write')
    return page


if __name__ == '__main__':
    output = {}
    for name, ru in pages:
        f = root / name
        if not f.is_file():
            raise SystemExit(f'Missing {name}; run in repository root')
        output[name] = transform(f.read_text(encoding='utf-8'), ru)
    for name, data in output.items():
        (root / name).write_text(data, encoding='utf-8')
        print(f'Updated {name} footer (no black strips; tag window hidden by default)')
