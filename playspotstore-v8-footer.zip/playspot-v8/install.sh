#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != 'main' ]]; then
  echo 'This installer expects the main branch. Run: git switch main' >&2
  exit 1
fi
# Never overwrite user edits to either homepage file.
if ! git diff --quiet HEAD -- index.html ru.html; then
  echo 'index.html / ru.html has local changes. Commit or stash those changes first.' >&2
  exit 1
fi
if [[ ! -f 'playspot-v8/apply.py' ]]; then
  echo 'Unzip playspotstore-v8-footer.zip into the repository root first.' >&2
  exit 1
fi
python3 playspot-v8/apply.py
cp playspot-v8/playspot-v8.css playspot-v8.css
cp playspot-v8/playspot-v8.js playspot-v8.js
# Include only the intended update files in the new commit.
git add -- index.html ru.html playspot-v8.css playspot-v8.js
if git diff --cached --quiet -- index.html ru.html playspot-v8.css playspot-v8.js; then
  echo 'No changes to publish.'
  exit 0
fi
git commit -m 'Design: seamless neon footer and hidden searchable tags' -- index.html ru.html playspot-v8.css playspot-v8.js
git push origin main
echo 'SUCCESS: PlaySpotStore V8 footer published to main.'
