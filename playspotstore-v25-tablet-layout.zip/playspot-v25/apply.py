#!/usr/bin/env python3
"""Idempotent PlaySpotStore V25 tablet adaptation (RO+RU; keep iPad mini)."""
from pathlib import Path
import re, shutil
root=Path.cwd(); assets=Path(__file__).resolve().parent
for p in ('index.html','ru.html','neon-v5-fixes.js'):
    if not (root/p).is_file(): raise SystemExit(f'ERROR: Missing {p}; run from repo root')
# Widen the existing, well-tested menu relocation breakpoint instead of layering
# a second competing resize handler. Non-touch desktops >1430 keep full menu.
source=root/'neon-v5-fixes.js'
s=source.read_text(encoding='utf-8')
old="const mq = window.matchMedia('(max-width: 950px)');"
new="const mq = window.matchMedia('(max-width: 1430px), (min-width: 1431px) and (max-width: 1535px) and (any-pointer: coarse)');"
if s.count(old)==1: s=s.replace(old,new,1)
elif s.count(new)!=1: raise SystemExit('ERROR: V5 menu code changed; cannot patch safely')
source.write_text(s,encoding='utf-8')
for filename in ('index.html','ru.html'):
    path=root/filename;s=path.read_text(encoding='utf-8')
    if s.count('</head>')!=1: raise SystemExit(f'ERROR: Malformed {filename}')
    s=re.sub(r'(?m)^[ \t]*<link\s+rel="stylesheet"\s+href="playspot-v25\.css[^"]*"[ \t]*>\r?\n','',s)
    s=s.replace('</head>','  <link rel="stylesheet" href="playspot-v25.css?v=20261108-v25a">\n</head>',1)
    path.write_text(s,encoding='utf-8')
shutil.copy2(assets/'playspot-v25.css',root/'playspot-v25.css')
print('V25: responsive tablet menu and layout ready (RO + RU), iPad mini unchanged')
