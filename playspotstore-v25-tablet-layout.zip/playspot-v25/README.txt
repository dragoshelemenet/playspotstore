PlaySpotStore V25 — Large-tablet responsive update

Fixes: iPad Pro 13 (1032 / 1376 CSS px), Surface Pro 10 (portrait 960, touch landscape ~1440), Nest Hub Max 1280x800.
The 2-row desktop menu in the 951-1430px breakpoint was cramped. Tablet devices now use a single-row header with brand logo, centered SPIN & WIN and hamburger navigation. The same menu is moved safely outside the header using the existing v5 controller. Categories become 3 columns, hero is shorter on landscape smart displays, and the category/search dialogs stay within available viewport height.

<=950px iPad mini and phone styles are not modified.
Non-touch desktop over 1430px keeps the desktop navigation.
RO / RU both included. Existing products, sale, search and Spin & Win logic untouched.

Steps:
1. Upload playspotstore-v25-tablet-layout.zip to the Codespaces repository root.
2. Execute:
   git pull --ff-only origin main && unzip -o playspotstore-v25-tablet-layout.zip -d . && bash playspot-v25/install.sh
3. Hard-refresh site / wait for hosting deployment.

Installer patches the existing neon-v5-fixes.js media breakpoint and adds playspot-v25.css to both HTML pages.
