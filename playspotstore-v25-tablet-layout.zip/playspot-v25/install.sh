#!/usr/bin/env bash
set -euo pipefail
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
 echo 'ERROR: run from PlaySpotStore Git repository root' >&2;exit 1
fi
git pull --ff-only origin main
python3 playspot-v25/apply.py
git add index.html ru.html neon-v5-fixes.js playspot-v25.css
if git diff --cached --quiet; then
 echo 'V25 already installed; no changes to commit.'
else
 git commit -m 'V25: improve iPad Pro, Surface Pro and Nest Hub Max layout'
 git push origin main
fi
echo 'SUCCESS: V25 responsive tablet update installed'
