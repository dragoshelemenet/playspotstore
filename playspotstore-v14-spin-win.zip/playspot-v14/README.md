# PlaySpotStore V14 • Rotește și câștigă 10%

Run inside GitHub Codespaces **from the repository root**:

```bash
git pull --ff-only origin main && unzip -o playspotstore-v14-spin-win.zip -d . && bash playspot-v14/install.sh
```

New UI: promotional CTA near the navigation inside the hero; mobile and desktop neon wheel; 8 randomly sampled games each spin from PS2, PS4, PS5, Nintendo and Xbox; 3 spins per calendar day in the `Europe/Chisinau` timezone; 10% discount for every drawn game; persistent daily award history; generated PNG receipt and prefilled WhatsApp message with same reference code; localized RO and RU.

Important: This static GitHub Pages implementation uses `localStorage` for the 3/day limit. That limit **is per browser/device, not secure against a deliberate user clearing storage or changing the code**. Receipts are client-generated and can be edited, so they are **not proof of eligibility without manual verification**. For a verifiable commercial promotion, use a backend with signed one-use vouchers, a server-side spin quota per customer, redemption log, and promotion terms. Do not claim this implementation prevents abuse.
