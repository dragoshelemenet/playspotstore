#!/usr/bin/env bash
# PlaySpotStore V14 — run from the repository root in GitHub Codespaces.
set -euo pipefail
printf '\n=== PLAYSPOTSTORE V14 / SPIN & WIN ===\n'
ROOT="$(pwd)"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -d .git || ! -f index.html || ! -f ru.html || ! -d data ]]; then
  echo 'ERROR: Run this from the playspotstore repository root.' >&2; exit 1
fi
if [[ "$(git branch --show-current)" != 'main' ]]; then
  echo 'ERROR: Switch to the main branch first; no files changed.' >&2; exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo 'ERROR: You have tracked, uncommitted changes. Commit/stash them first. No files changed.' >&2
  git status --short; exit 1
fi
# Always pull main before touching site files; --ff-only never silently rewrites history.
echo 'Pulling latest main...'
git pull --ff-only origin main
node --check "$SOURCE_DIR/playspot-v14.js"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]); paths=[root/'index.html',root/'ru.html']
for p in paths:
    html=p.read_text(encoding='utf-8')
    if html.count('</head>')!=1 or html.count('</body>')!=1 or '<section class="hero"' not in html:
        raise SystemExit(f'Unexpected HTML structure: {p}; no files changed')
    if ('playspot-v14.js' in html) != ('playspot-v14.css' in html):
        raise SystemExit(f'Incomplete V14 reference in {p}; no files changed')
    if 'playspot-v13.js' not in html:
        raise SystemExit(f'V13 integration not found in {p}; no files changed')
for p in paths:
    html=p.read_text(encoding='utf-8')
    if 'playspot-v14.css' not in html:
        html=html.replace('</head>', '  <link rel="stylesheet" href="playspot-v14.css?v=20261108-1">\n</head>',1)
        html=html.replace('</body>', '  <script defer src="playspot-v14.js?v=20261108-1"></script>\n</body>',1)
    p.write_text(html,encoding='utf-8')
print('RO and RU: linked V14 assets successfully.')
PY
cp "$SOURCE_DIR/playspot-v14.js" ./playspot-v14.js
cp "$SOURCE_DIR/playspot-v14.css" ./playspot-v14.css
node --check ./playspot-v14.js
python3 - <<'PY'
from pathlib import Path
for path in ('index.html','ru.html'):
    s=Path(path).read_text(encoding='utf-8')
    assert s.count('playspot-v14.css?v=20261108-1')==1
    assert s.count('playspot-v14.js?v=20261108-1')==1
print('HTML and JavaScript checks passed.')
PY
git add index.html ru.html playspot-v14.js playspot-v14.css
if git diff --cached --quiet; then
  echo 'Nothing to commit.'
else
  git -c user.name="PlaySpotStore Codespaces" -c user.email="codespaces@users.noreply.github.com" commit -m "Add 3 daily spins and 10 percent discount wheel"
  git push origin main
fi
printf '\nSUCCESS: V14 pushed to main. Refresh the website to see Spin & Win.\n'
