#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f index.html || ! -f ru.html || ! -d .git ]]; then
  echo "ERROR: Run from the root of your playspotstore Git repository." >&2
  exit 1
fi
git pull --ff-only origin main
python3 playspot-v20/apply.py
cp -f playspot-v20/playspot-v20.css ./playspot-v20.css
cp -f playspot-v20/playspot-v20.js ./playspot-v20.js
mkdir -p media/tiktok
cp -f playspot-v20/media/tiktok/* media/tiktok/
git add index.html ru.html playspot-v20.css playspot-v20.js media/tiktok
if git diff --cached --quiet; then
  echo "V20 already installed. No new changes."
else
  git commit -m "Replace blocked TikTok embed with five local animated previews"
  git push origin main
  echo "SUCCESS: PlaySpotStore V20 published to main."
fi
