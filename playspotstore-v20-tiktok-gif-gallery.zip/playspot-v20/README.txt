PlaySpotStore V20 — Five animated TikTok previews (Nov 2026)

Exactly 5 provided screen-recordings trimmed to cursor-free segments.
Each provided TikTok URL belongs to the matching clip in its original order.
Instead of TikTok blocking embedded feeds, local looping animated WebP images display,
with GIF fallback and a static JPEG for users preferring reduced motion.
Tiles link to actual TikTok videos; More button links to @playspotstore.

Install from GitHub Codespaces repository root:
git pull --ff-only origin main && unzip -o playspotstore-v20-tiktok-gif-gallery.zip -d . && bash playspot-v20/install.sh

Individual GIFs are separately available in playspotstore-five-tiktok-gifs.zip.
This is a manual five-video selection. Adding future TikTok uploads requires updating
these media previews/URLs, not an automatic TikTok API feed.
