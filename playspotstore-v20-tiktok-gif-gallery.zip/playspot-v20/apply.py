#!/usr/bin/env python3
"""Idempotent update: replace broken TikTok embedded feed with five local loops."""
from pathlib import Path
import re
root=Path.cwd()
here=Path(__file__).resolve().parent
pattern=re.compile(r'<!-- PlaySpotStore V19: TikTok native recent-videos creator feed -->\s*<section class="p19-tiktok-feed"[\s\S]*?</section>\s*(?=<section class="features">)')
for name,lang in [('index.html','ro'),('ru.html','ru')]:
    source=root/name
    if not source.is_file(): raise SystemExit(f'Missing {source}')
    html=source.read_text(encoding='utf-8')
    if 'id="p20-tiktok-gallery"' not in html:
        new,n=pattern.subn(lambda _ : (here/f'section_{lang}.html').read_text(encoding='utf-8')+'\n',html,count=1)
        if n!=1: raise SystemExit(f'Cannot locate original TikTok gallery in {source}')
        html=new
    html=re.sub(r'\s*<script\s+defer\s+src="playspot-v19\.js\?[^\"]+"\s*></script>','',html)
    for file,anchor,line in [
        ('playspot-v20.css','</head>','  <link rel="stylesheet" href="playspot-v20.css?v=20261108-v20">\n'),
        ('playspot-v20.js','</body>','  <script defer src="playspot-v20.js?v=20261108-v20"></script>\n')
    ]:
        if file not in html:
            if anchor not in html: raise SystemExit(f'{anchor} missing in {source}')
            html=html.replace(anchor,line+anchor,1)
    source.write_text(html,encoding='utf-8')
    print('Updated',name)
