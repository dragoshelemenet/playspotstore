#!/usr/bin/env python3
"""Apply PlaySpotStore V24 to both languages, idempotently and without editing catalog data."""
from pathlib import Path
import re, shutil

root = Path.cwd()
asset = Path(__file__).resolve().parent
required = ('index.html','ru.html')
for filename in required:
    if not (root/filename).is_file():
        raise SystemExit(f'ERROR: Run installer from PlaySpotStore repository root, missing {filename}')

for filename in required:
    target = root/filename
    src = target.read_text(encoding='utf-8')
    s = src
    # Ensure the original working global search is the first entry in the hamburger menu.
    match = re.search(r'<li\s+class="mobile-search-bar"\s*>[\s\S]*?</li>', s)
    if not match:
        raise SystemExit(f'ERROR: Could not find mobile global search in {filename}')
    mobile_search = match.group(0)
    s = s[:match.start()] + s[match.end():]
    needle = '<ul id="main-menu">'
    if s.count(needle)!=1:
        raise SystemExit(f'ERROR: Cannot locate unique menu in {filename}')
    s = s.replace(needle, needle+mobile_search,1)
    # Reference new separate CSS/JS versions so browser caches cannot reuse old code.
    s = re.sub(r'[ \t]*<link[ \t]+rel="stylesheet"[ \t]+href="playspot-v24\.css[^\"]*"[ \t]*>\r?\n?', '', s)
    s = re.sub(r'[ \t]*<script[ \t]+defer[ \t]+src="playspot-v24\.js[^\"]*"[ \t]*>[ \t]*</script>\r?\n?', '', s)
    if '</head>' not in s or '</body>' not in s:
        raise SystemExit(f'ERROR: malformed HTML in {filename}')
    s = s.replace('</head>', '  <link rel="stylesheet" href="playspot-v24.css?v=20261108-v24b">\n</head>', 1)
    s = s.replace('</body>', '  <script defer src="playspot-v24.js?v=20261108-v24b"></script>\n</body>', 1)
    if s != src:
        target.write_text(s,encoding='utf-8')
    print(f'V24: patched {filename}')
for name in ['playspot-v24.css','playspot-v24.js']:
    shutil.copy2(asset/name,root/name)
    print(f'V24: installed {name}')
print('V24: ready; no catalog records were changed')
