#!/usr/bin/env bash
set -euo pipefail
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo 'ERROR: run this script from the PlaySpotStore Git repository root' >&2; exit 1
fi
# Pull again as a safeguard; the user-facing command also pulls first.
git pull --ff-only origin main
python3 playspot-v24/apply.py
git add index.html ru.html playspot-v24.css playspot-v24.js
if git diff --cached --quiet; then
  echo 'V24 already installed; no changes to commit.'
else
  git commit -m 'V24: hamburger search first and scoped floating category search'
  git push origin main
fi
echo 'SUCCESS: V24 installed; hard refresh the storefront to load new assets.'
