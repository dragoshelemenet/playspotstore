PlaySpotStore V24 — Scoped Floating Search (RO + RU)

1. Upload playspotstore-v24-category-search.zip into Codespaces at the root of your playspotstore repository.
2. In Codespaces terminal (from repository root) run EXACTLY:

git pull --ff-only origin main && unzip -o playspotstore-v24-category-search.zip -d . && bash playspot-v24/install.sh

What's new:
• Mobile hamburger: existing, working global search input is now the FIRST menu element.
• In PS4, PS5, Nintendo, Xbox, PS2, Console and Accessories catalogs, a semi-transparent search dock sticks near the bottom while browsing.
• Touch/focus opens contextual search results ONLY for the current category.
• Search panel shows the number of matches and quick switching buttons to all categories.
• Selecting a result opens its existing product dialog. The search hides under product/order dialogs.
• Romanian and Russian support. Current game products, spin, menus and price data untouched.

The search dock is an addition; it does not modify the site's existing global search mechanism.
