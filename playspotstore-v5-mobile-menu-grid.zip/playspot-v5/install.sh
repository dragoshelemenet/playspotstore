#!/usr/bin/env bash
set -euo pipefail
ROOT=$(git rev-parse --show-toplevel 2>/dev/null) || { echo 'ERROR: Open the PlaySpotStore GitHub Codespace first.'; exit 1; }
cd "$ROOT"
case "$(git remote get-url origin 2>/dev/null || true)" in
 *dragoshelemenet/playspotstore*) ;;
 *) echo 'ERROR: Wrong repository. Nothing changed.'; exit 1;;
esac
if [ "$(git branch --show-current)" != main ]; then echo 'ERROR: Switch to main first (git switch main).'; exit 1; fi
if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
  echo 'ERROR: There are uncommitted changes to tracked files; commit or stash them first:'
  git status --short
  exit 1
fi
# Always pull latest before making any website edits.
git pull --ff-only origin main
for f in index.html ru.html neon-v3.css; do
  if [ ! -f "$f" ]; then echo "ERROR: Expected file missing: $f"; exit 1; fi
done
if [ ! -f 'playspot-v5/neon-v5-fixes.css' ] || [ ! -f 'playspot-v5/neon-v5-fixes.js' ]; then
  echo 'ERROR: Unzip playspotstore-v5-mobile-menu-grid.zip in the repository root first.'; exit 1
fi
cp playspot-v5/neon-v5-fixes.css ./neon-v5-fixes.css
cp playspot-v5/neon-v5-fixes.js ./neon-v5-fixes.js
python3 - <<'PY'
from pathlib import Path
from html.parser import HTMLParser

css = '<link rel="stylesheet" href="neon-v5-fixes.css?v=20261105a">'
js = '<script defer src="neon-v5-fixes.js?v=20261105a"></script>'
for name in ('index.html', 'ru.html'):
    p = Path(name)
    html = p.read_text(encoding='utf-8')
    if html.count('</head>') != 1 or html.count('</body>') != 1:
        raise SystemExit(f'ERROR: Unexpected document layout in {name}; stopping safely.')
    # Avoid whitespace changes and duplicate tags on repeated installs.
    if html.count(css) == 1 and html.count(js) == 1:
        print('  ✓ Already installed in', name)
        continue
    import re
    html = re.sub(r'\s*<link\s+rel="stylesheet"\s+href="neon-v5-fixes\.css\?v=[^"]+">', '', html)
    html = re.sub(r'\s*<script\s+defer\s+src="neon-v5-fixes\.js\?v=[^"]+"></script>', '', html)
    html = html.replace('</head>', '  ' + css + '\n</head>', 1)
    html = html.replace('</body>', js + '\n</body>', 1)
    p.write_text(html, encoding='utf-8')
    print('  ✓ Updated', name)
print('  ✓ Responsive grid: 2 columns on phones / 3 tablets / 4 desktop')
print('  ✓ Mobile menu overlay no longer trapped within header')
PY

git add -- index.html ru.html neon-v5-fixes.css neon-v5-fixes.js
if git diff --cached --quiet; then
  echo 'Already installed — no changes to push.'
  exit 0
fi
git -c user.name='PlaySpotStore Updates' -c user.email='play-spot-updates@users.noreply.github.com' commit -m 'Fix mobile navigation overlay and responsive game modal grid'
if git push origin main; then
  echo 'SUCCESS: PlaySpotStore V5 mobile menu + grid pushed to main.'
  echo 'Refresh https://playstationspot.store/ once GitHub Pages is deployed.'
else
  echo 'Git push failed; changes are committed locally. Run: git push origin main'
  exit 1
fi
