#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f index.html || ! -f ru.html || ! -d .git ]]; then
  echo 'ERROR: run this from the playspotstore Codespaces repository root.' >&2
  exit 1
fi
git pull --ff-only origin main
python3 playspot-v28/apply.py
if git diff --quiet -- index.html ru.html; then
  echo 'Already up to date. Nothing to commit.'
  exit 0
fi
git add index.html ru.html
git commit -m 'V28: simplify visitor counter footer labels'
git push origin main
echo 'SUCCESS: V28 installed and pushed to main.'
