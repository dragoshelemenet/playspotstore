PlaySpotStore V28 — Counter footer text cleanup (RO + RU)

Removes ONLY the two visible explanatory lines below the "Visitors 2026" label.
Preserves the existing displayed counter number, preset starting value,
server API behavior, browser deduplication, and accessibility metadata.

Prerequisite: V27 already deployed to main.

Upload playspotstore-v28-counter-cleanup.zip to repository root,
then run:

git pull --ff-only origin main && unzip -o playspotstore-v28-counter-cleanup.zip -d . && bash playspot-v28/install.sh

No SEO changes included; those will be handled separately.
