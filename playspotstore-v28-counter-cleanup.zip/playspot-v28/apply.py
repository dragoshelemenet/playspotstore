#!/usr/bin/env python3
"""V28: remove two verbose visible baseline notes, preserving the numeric counter."""
from pathlib import Path
import re
import sys

pages = [Path('index.html'), Path('ru.html')]
for page in pages:
    if not page.exists():
        sys.exit(f'ERROR: {page} is missing. Run from your playspotstore repository root.')
    html = page.read_text(encoding='utf-8')
    if 'p26-visitor-counter' not in html or 'p26-total' not in html:
        sys.exit(f'ERROR: visitor counter not found in {page}. Install V27 first.')

    # The public label and the actual measured counter are preserved. The
    # two visible <small> notes are removed; JS safely tolerates no #p27-status.
    pattern = (r'(<div class="p26-copy"><strong>[^<]+</strong>)'
               r'<small>[^<]*</small>'
               r'<small id="p27-status"[^>]*>[^<]*</small>'
               r'(</div>)')
    new_html, count = re.subn(pattern, r'\1\2', html, count=1)
    if count == 0:
        # Idempotent: don't needlessly modify an already patched page.
        if '<div class="p26-copy"><strong>' in html and 'id="p27-status"' not in html:
            print(f'ALREADY DONE: {page}')
            continue
        sys.exit(f'ERROR: unexpected counter markup in {page}; no changes saved.')
    page.write_text(new_html, encoding='utf-8')
    print(f'UPDATED: {page} (removed two explanatory notes, counter unchanged)')
print('SUCCESS: V28 footer text cleanup complete.')
