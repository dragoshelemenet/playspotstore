#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
printf '\n=== PLAYSPOTSTORE V10 — ROTATING SALE BANNERS ===\n'
if [[ "$(git branch --show-current)" != 'main' ]]; then
  echo "Please switch to main first: git switch main" >&2; exit 1
fi
for f in index.html ru.html playspot-v10.css playspot-v10.js media/sale/sale-live.webp media/sale/hot-deals.webp media/sale/limited-offers.webp media/sale/sale-live-mobile.webp media/sale/hot-deals-mobile.webp media/sale/limited-offers-mobile.webp; do
  if [[ -e "$f" ]] && ! git diff --quiet HEAD -- "$f"; then
    echo "Uncommitted tracked edit in $f. Commit or stash before update." >&2; exit 1
  fi
done
# Pull first even when someone invokes the installer without running the provided command.
git pull --ff-only origin main
if [[ ! -f playspot-v10/apply.py ]]; then
  echo 'Upload and unzip the V10 package inside the repository first.' >&2; exit 1
fi
python3 playspot-v10/apply.py
cp playspot-v10/playspot-v10.css playspot-v10.css
cp playspot-v10/playspot-v10.js playspot-v10.js
mkdir -p media/sale
cp playspot-v10/media/sale/*.webp media/sale/
# Stage only intended website files, never ZIP or install helper files.
git add -- index.html ru.html playspot-v10.css playspot-v10.js media/sale/sale-live.webp media/sale/hot-deals.webp media/sale/limited-offers.webp media/sale/sale-live-mobile.webp media/sale/hot-deals-mobile.webp media/sale/limited-offers-mobile.webp
if git diff --cached --quiet; then
  echo 'V10 already installed; no changes.'; exit 0
fi
git -c user.name="PlaySpotStore Design" -c user.email="playspotstore-update@users.noreply.github.com" commit -m 'Design: add scroll-aware sale banner carousel V10' -- index.html ru.html playspot-v10.css playspot-v10.js media/sale/sale-live.webp media/sale/hot-deals.webp media/sale/limited-offers.webp media/sale/sale-live-mobile.webp media/sale/hot-deals-mobile.webp media/sale/limited-offers-mobile.webp
git push origin main
printf '\nSUCCESS: PlaySpotStore V10 published to main.\n'
