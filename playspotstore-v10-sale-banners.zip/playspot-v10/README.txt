PlaySpotStore V10: rotating Sale-section banners

1. Upload playspotstore-v10-sale-banners.zip to the root of your GitHub Codespace.
2. In the terminal paste:

   git pull --ff-only origin main && unzip -o playspotstore-v10-sale-banners.zip -d . && bash playspot-v10/install.sh

What it does:
- Adds the 3 neon sale banners to Sale only (index.html and ru.html).
- Desktop: center banner plus two smaller dimmed neighboring previews.
- Mobile: one banner with larger readable text and swipe support.
- Automatically changes every 4.8 seconds while Sale is visible; pauses offscreen, on hover, keyboard focus and inactive browser tab.
- Center banner opens existing sale products. No overlays or permanent popups.
- Uses 3 desktop + 3 phone-optimized self-hosted WebP banners, combined < 650 KB.
- No changes to JSON/product catalog, logo, other content or footer.
