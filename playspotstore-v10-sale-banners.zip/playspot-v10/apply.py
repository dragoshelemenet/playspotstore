#!/usr/bin/env python3
"""PlaySpotStore V10: add sale-only rotating promo banners in both languages.

Deliberately does not change any existing products, JSON files, logo, modals or footer.
"""
from pathlib import Path
from html import escape
import re

root=Path.cwd()
required=['playspot-v9.css','index.html','ru.html']
for name in required:
    if not (root/name).is_file():
        raise SystemExit(f'Missing {name}. Run the installer inside the PlaySpotStore repo after git pull.')

BANNERS=[
  ('sale-live.webp','BIG GAME SALE','IS LIVE!',
   'Reduceri la jocuri PS4, PS5, Nintendo și Xbox',
   'Скидки на игры PS4, PS5, Nintendo и Xbox',
   'VEZI OFERTELE','ПОСМОТРЕТЬ СКИДКИ'),
  ('hot-deals.webp','HOT DEALS','THIS WEEK',
   'Oferte limitate și jocuri populare la preț bun',
   'Выгодные предложения и популярные игры',
   'VEZI OFERTELE','ПОСМОТРЕТЬ СКИДКИ'),
  ('limited-offers.webp','LIMITED TIME','OFFERS',
   'Stoc limitat. Comandă rapid jocurile dorite',
   'Количество ограничено. Выбирайте любимые игры',
   'VEZI ACUM','СМОТРЕТЬ СЕЙЧАС')
]

def build_section(lang, timer):
    ru=lang=='ru'
    tag='АКЦИИ PLAYSPOTSTORE' if ru else 'OFERTĂ PLAYSPOTSTORE'
    hidden='Скидки на игры' if ru else 'Oferte la jocuri'
    dots='Слайд' if ru else 'Banner'
    label='Акционные баннеры' if ru else 'Bannere promoționale'
    items=[]
    for i,(filename,en,em,ro_caption,ru_caption,ro_cta,ru_cta) in enumerate(BANNERS):
        descr=ru_caption if ru else ro_caption
        cta=ru_cta if ru else ro_cta
        state=['active','next','prev'][i]
        src=f'media/sale/{filename}'
        mobile=f'media/sale/{filename.replace(".webp","-mobile.webp")}'
        items.append(f'''<a class="p10-slide" href="#promo-products" data-index="{i}" data-position="{state}" aria-label="{escape(en+' '+em+'. '+descr)}" {'aria-current="true"' if i==0 else ''}>
          <picture><source media="(max-width: 700px)" srcset="{mobile}"><img src="{src}" width="1800" height="600" loading="lazy" decoding="async" alt="{escape(en+' '+em)}"></picture>
          <span class="p10-mobile-caption" aria-hidden="true"><strong>{escape(en)} <em>{escape(em)}</em></strong><small>{escape(descr)}</small><span class="p10-mobile-cta">{escape(cta)} &rsaquo;</span></span>
        </a>''')
    dots_html=''.join(f'<button type="button" class="p10-dot" data-label="{dots}" aria-label="{dots} {i+1}" aria-current="{"true" if i==0 else "false"}"></button>' for i in range(3))
    bars=''.join('<span></span>' for _ in range(42))
    return f'''<section class="season-promotions p10-sale-wrap" id="sale">
  <h2 class="p10-sr-only">{hidden}</h2>
  <div class="p10-sale-shell">
    <div class="p10-sale-eyebrow">{tag}</div>
    <div class="p10-carousel" id="p10-sale-carousel" role="region" aria-roledescription="carousel" aria-label="{label}">
      <div class="p10-stage" tabindex="0">
        {''.join(items)}
        <button type="button" class="p10-nav p10-previous" aria-label="{'Предыдущий баннер' if ru else 'Banner anterior'}">&#8249;</button>
        <button type="button" class="p10-nav p10-next" aria-label="{'Следующий баннер' if ru else 'Banner următor'}">&#8250;</button>
      </div>
      <div class="p10-pagination" role="group" aria-label="{'Выбрать баннер' if ru else 'Alege bannerul'}">{dots_html}</div>
    </div>
    {timer}
    <div class="p10-timer-bars" aria-hidden="true">{bars}</div>
  </div>
</section>'''

replaced={}
for name in ['index.html','ru.html']:
    p=root/name
    s=p.read_text(encoding='utf-8')
    if s.count('</head>')!=1 or s.count('</body>')!=1:
        raise SystemExit(f'Unexpected head/body tags in {name}; no files changed.')
    if s.count('playspot-v9.css')!=1:
        raise SystemExit(f'Expected V9 stylesheet in {name}; no files changed.')
    if 'p10-sale-carousel' not in s:
        match=re.search(r'<section class="season-promotions">[\s\S]*?</section>',s)
        if not match:
            raise SystemExit(f'Sale section missing in {name}; no files changed.')
        timer=re.search(r'<div id="countdown-timer">[^<]*</div>',match.group(0))
        if not timer:
            raise SystemExit(f'Sale countdown missing in {name}; no files changed.')
        s=s[:match.start()]+build_section('ru' if name=='ru.html' else 'ro',timer.group(0))+s[match.end():]
    if 'playspot-v10.css' not in s:
        s=s.replace('</head>','  <link rel="stylesheet" href="playspot-v10.css?v=20261105b">\n</head>',1)
    if 'playspot-v10.js' not in s:
        s=s.replace('</body>','  <script defer src="playspot-v10.js?v=20261105b"></script>\n</body>',1)
    for needle in ['p10-sale-carousel','playspot-v10.css','playspot-v10.js']:
        if s.count(needle)!=1: raise SystemExit(f'Duplicate or missing {needle} in {name}; no files changed.')
    replaced[p]=s
for p,s in replaced.items():
    p.write_text(s,encoding='utf-8')
    print(f'Updated {p.name} with sale banners')
print('Done: V10 sale-only carousel, rotating 3 banners (1 per phone screen).')
