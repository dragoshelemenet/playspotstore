#!/usr/bin/env bash
set -euo pipefail
# Place the ZIP in the main repository directory, unzip, then run installer.
if [[ ! -d .git || ! -f index.html || ! -f ru.html || ! -f playspot-v29/generate.py ]]; then
  echo 'ERROR: Open GitHub Codespaces at the PlaySpotStore repository root.' >&2
  exit 1
fi
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'ERROR: Tracked changes are uncommitted. Commit or stash them before installation.' >&2
  exit 1
fi
git pull --ff-only origin main
for f in playspot-v40/apply.py playspot-v40/validate.py playspot-v41/editorial-facts.tsv playspot-v40/descriptions.tsv; do
  if [[ ! -s "$f" ]]; then echo "ERROR: Missing $f. Install V41 first." >&2; exit 1; fi
done
cp -f playspot-v42/playspot-v42.css playspot-v42.css
python3 -B playspot-v42/rewrite.py --root . --check
python3 -B playspot-v42/rewrite.py --root .
# Use the existing HTML renderer; V42 adds a separate, explicitly editorial UI.
python3 -B playspot-v40/apply.py --root .
python3 -B playspot-v42/validate.py --root .
python3 -B playspot-v40/validate.py --root .
python3 -B playspot-v29/validate.py --root .
git add -A -- playspot-v42/ playspot-v42.css data/ produse/ ru/produse/ playspot-v29/generate.py
if git diff --cached --quiet; then
  echo 'V42 already installed; nothing to commit.'
else
  git commit -m 'V42: bilingual editorial gameplay impressions and focused SEO metadata'
  git push origin main
fi
echo 'SUCCESS: V42 editorial product content installed. GitHub Pages will deploy normally.'
