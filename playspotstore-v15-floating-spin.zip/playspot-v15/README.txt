PlaySpotStore V15 – Floating Spin CTA + 30-day promotion expiry

Upload playspotstore-v15-floating-spin.zip into the root of your GitHub Codespace.
Execute:

git pull --ff-only origin main && unzip -o playspotstore-v15-floating-spin.zip -d . && bash playspot-v15/install.sh

The installer sets ONE campaign end date 30 days after first deployment
in Europe/Chisinau time, stored in spin-campaign.json and the site JS.
Reinstalling does not extend the promotion.

The fixed bottom bar can be minimized to a small pill, and it stays on-screen
while browsing. The wheel stops accepting spins at the shared campaign end.
Existing daily spins and prizes are kept.

IMPORTANT: V14 limits spins with browser localStorage, not per customer.
Claims and screenshots remain client-generated and need manual verification.
