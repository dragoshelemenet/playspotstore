#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
[[ -f index.html && -f ru.html && -f playspot-v14.js ]] || { echo 'Run this from the playspotstore repo root after pulling main.' >&2; exit 1; }
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'Tracked files have uncommitted changes. Commit or stash those changes before installing.' >&2
  git status --short
  exit 1
fi
python3 playspot-v15/install.py
if command -v node >/dev/null 2>&1; then
  node --check playspot-v14.js
  node --check playspot-v15.js
fi
# Stage ONLY V15 files plus the source wheel guard. Do not include user ZIPs or other work.
git add index.html ru.html playspot-v14.js playspot-v15.css playspot-v15.js spin-campaign.json
if git diff --cached --quiet; then
  echo 'V15 is already installed. No new commit necessary.'
  exit 0
fi
git -c user.name="PlaySpotStore" -c user.email="playspotstore@users.noreply.github.com" commit -m "Add fixed floating spin bar and 30-day campaign expiry"
git push origin HEAD:main
echo 'SUCCESS — PlaySpotStore V15 deployed to GitHub main.'
