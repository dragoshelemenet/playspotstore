#!/usr/bin/env python3
"""Install PlaySpotStore V15 without resetting the campaign if re-run."""
import json
import re
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
TARGETS = [ROOT / 'index.html', ROOT / 'ru.html']
V14 = ROOT / 'playspot-v14.js'
CONF = ROOT / 'spin-campaign.json'

for p in [*TARGETS, V14]:
    if not p.is_file():
        raise SystemExit(f'ERROR: Missing {p.name}. Run from your playspotstore repository root.')

if CONF.exists():
    config = json.loads(CONF.read_text(encoding='utf-8'))
    end_iso = config['expires_at']
    if not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\+\d\d:\d\d', end_iso):
        raise SystemExit('ERROR: spin-campaign.json contains an invalid expiration timestamp')
    print('Existing campaign expiry preserved:', end_iso)
else:
    start = datetime.now(ZoneInfo('Europe/Chisinau')).replace(microsecond=0)
    end = start + timedelta(days=30)
    end_iso = end.isoformat(timespec='seconds')
    config = {
        'campaign': 'PlaySpotStore Spin & Win — 10% discount',
        'start_at': start.isoformat(timespec='seconds'),
        'expires_at': end_iso,
        'timezone': 'Europe/Chisinau',
        'duration_days': 30,
        'max_daily_spins_per_browser': 3,
        'discount_percent': 10,
        'note': 'Browser-only limit; prizes require manual shop verification.'
    }
    print('New campaign: ', config['start_at'], 'to', end_iso)


def replace_once(source, before, after, label):
    if before not in source:
        raise ValueError(f'V14 layout changed: could not find {label}')
    if source.count(before) != 1:
        raise ValueError(f'Unexpected duplicate {label}')
    return source.replace(before, after, 1)

# Keep the existing wheel, its randomness, and its 3-per-day browser limit.
js = V14.read_text(encoding='utf-8')
if 'const p15CampaignExpired' not in js:
    js = replace_once(js, '  const maxSpins = 3;',
        "  const maxSpins = 3;\n"
        f"  const p15ExpiresAt = Date.parse('{end_iso}');\n"
        "  const p15CampaignExpired = () => Date.now() >= p15ExpiresAt;\n"
        "  const p15ExpiryLabel = new Intl.DateTimeFormat(ru ? 'ru-RU' : 'ro-RO',"
        "{timeZone:'Europe/Chisinau', day:'numeric',month:'long',year:'numeric'}).format(p15ExpiresAt);",
        'campaign date / guards')
    js = replace_once(js,
        'spinBtn.disabled=spinning || left===0 || !pool;',
        'spinBtn.disabled=spinning || left===0 || !pool || p15CampaignExpired();',
        'disable spin after expiry')
    js = replace_once(js,
        'if(left===0 && !spinning)status.textContent=t.complete;',
        "if(p15CampaignExpired())status.textContent=ru?'Акция завершилась.':'Campania a expirat.';\n"
        "    else if(left===0 && !spinning)status.textContent=t.complete;",
        'expiry status')
    js = replace_once(js,
        '  const open=()=>{\n',
        '  const open=()=>{\n    if(p15CampaignExpired())return;\n',
        'prevent opening expired wheel')
    js = replace_once(js,
        "spinBtn.addEventListener('click',async()=>{\n    if(spinning)return;",
        "spinBtn.addEventListener('click',async()=>{\n    if(spinning || p15CampaignExpired())return;",
        'guard spin click')
    js = replace_once(js,
        '    const state=getState();if(state.wins.length>=maxSpins){refreshCounter();return;}',
        '    if(p15CampaignExpired()){refreshCounter();return;}\n'
        '    const state=getState();if(state.wins.length>=maxSpins){refreshCounter();return;}',
        'guard spin after asynchronous load')
    js = replace_once(js,
        "codeEl.textContent=win.code;claim.href='https://wa.me/'+cashPhone+'?text='+encodeURIComponent(t.message(win));",
        "codeEl.textContent=win.code;claim.href='https://wa.me/'+cashPhone+'?text='+"
        "encodeURIComponent(t.message(win)+(ru?' Срок акции: до ':' Campanie valabilă până la ')+p15ExpiryLabel+'.');",
        'append expiry to WhatsApp text')
    js = replace_once(js,
        'c.fillText(t.receiptFooter,95,596);',
        "c.fillText(t.receiptFooter+' · '+p15ExpiryLabel,95,596);",
        'append expiry to PNG proof')
else:
    # Safety: never silently move an already launched campaign date.
    existing = re.search(r"const p15ExpiresAt = Date.parse\('([^']+)'\)", js)
    if not existing or existing.group(1) != end_iso:
        raise SystemExit('ERROR: V14 JS campaign end differs from spin-campaign.json; refusing to reset it.')

html_outputs = {}
for page in TARGETS:
    html = page.read_text(encoding='utf-8')
    css_ref = 'playspot-v15.css?v=20261108'
    js_ref = 'playspot-v15.js?v=20261108'
    if css_ref not in html:
        if html.count('</head>') != 1:
            raise SystemExit(f'ERROR: Unexpected <head> structure in {page.name}')
        html = html.replace('</head>',f'  <link rel="stylesheet" href="{css_ref}">\n</head>',1)
    if js_ref not in html:
        if html.count('</body>') != 1:
            raise SystemExit(f'ERROR: Unexpected <body> structure in {page.name}')
        html = html.replace('</body>',f'  <script defer src="{js_ref}"></script>\n</body>',1)
    html_outputs[page] = html

v15 = (HERE / 'playspot-v15.js').read_text(encoding='utf-8')
if v15.count('__P15_EXPIRY_ISO__') != 1:
    raise SystemExit('ERROR: V15 template corrupt')
v15 = v15.replace('__P15_EXPIRY_ISO__',end_iso)
# Only write after every validation has passed.
CONF.write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
V14.write_text(js,encoding='utf-8')
for path,html in html_outputs.items(): path.write_text(html,encoding='utf-8')
(ROOT / 'playspot-v15.css').write_bytes((HERE / 'playspot-v15.css').read_bytes())
(ROOT / 'playspot-v15.js').write_text(v15,encoding='utf-8')
print('V15 files installed on both language versions. Campaign ends:',end_iso)
