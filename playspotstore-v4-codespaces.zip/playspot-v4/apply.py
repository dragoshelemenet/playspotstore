#!/usr/bin/env python3
"""PlaySpotStore V4: exact supplied brand + original online game cover URLs.
No cropping/reusing any user inventory photos. Uses remote image source URLs in JSON.
When source unverified, retains current entry and logs it for manual replacement.
"""
from __future__ import annotations
import concurrent.futures as cf
from difflib import SequenceMatcher
from html import unescape
from html.parser import HTMLParser
import json
import re
import os
import sys
import time
from functools import lru_cache
import unicodedata
from pathlib import Path
from urllib.parse import quote, urlencode, urlparse
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

ROOT=Path.cwd()
PACK=Path(__file__).resolve().parent
ASSET=PACK/'media'/'play-spot-logo-v4.webp'
UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
HEADERS={'User-Agent':UA,'Accept-Language':'en-US,en;q=0.9','Referer':'https://www.bing.com/'}
PLATFORMS=['ps2','ps4','ps5','nintendo','xbox','accessories']
PLABEL={'ps2':'PlayStation 2','ps4':'PlayStation 4','ps5':'PlayStation 5','nintendo':'Nintendo Switch','xbox':'Xbox Series X','accessories':'PlayStation'}
SEED={
 ('nintendo','Little Nightmares III'):'https://multimedia.bbycastatic.ca/multimedia/products/500x500/193/19370/19370833.jpg',
 ('nintendo','Sonic Racing: CrossWorlds'):'https://toyorgame.com.sg/cdn/shop/files/CoverNS2_85e595c7-6930-47a5-b46a-41cccb61ae79.png?v=1768789386',
 ('nintendo','Hyrule Warriors: Age of Imprisonment'):'https://bfasset.costco-static.com/U447IH35/as/58pvsqk68m3kp7p9nct9mp3/4000416710-847__1?auto=webp&format=jpg',
 ('nintendo','Street Fighter 6'):'https://www.canex.ca/media/catalog/product/n/i/nintendo-switch-2-street-fighter-6-years-1-2-fighters-ed-045496905507_b-0srms.jpg?bg-color=255%2C255%2C255&fit=bounds&quality=80',
 ('nintendo','Two Point Museum'):'https://toyorgame.com.sg/cdn/shop/files/CoverNS2_9f098eac-2d6f-498e-babe-6e1bb50192f3.png?v=1758512900',
 ('nintendo','RAIDOU Remastered: The Mystery of the Soulless Army'):'https://static.gamesmen.com.au/media/catalog/product/cache/57ddbad6affa8d28869fa47188b75842/r/a/raidou_packshot_nsw_front_anz.jpg',
 ('nintendo','Super Mario Maker 2'):'https://gorilagames.com/img/public/e4de21.jpg',
 ('nintendo','Kirby Star Allies'):'https://i5.walmartimages.com/asr/65be7e3c-a95f-4681-b33f-606743b81161_1.39741f163f474d0205b0f9df9c808f42.jpeg?odnBg=FFFFFF&odnHeight=2000&odnWidth=2000',
 ('nintendo','Cronos: The New Dawn'):'https://retromtl.com/cdn/shop/files/Switch2-CronosNewDawnNew.jpg?v=1761139187&width=1500',
 ('xbox','Cyberpunk 2077'):'https://videogamesplus.ca/cdn/shop/files/VGP0019019_1024x1024.png?v=1700587981',
 ('xbox','Mortal Kombat 1'):'https://i5.walmartimages.com/seo/Mortal-Kombat-1-Xbox-Series-X_e787da9b-e0d1-4ac8-a1bd-a179d987761a.e717e2ab1283b585921372f71df46667.png',
 ('xbox','Dragon’s Dogma 2'):'https://media.gamestop.com/i/gamestop/20009921-3f0862c8',
 ('ps2','SpongeBob SquarePants: The Movie'):'https://pixelparadise.co.nz/cdn/shop/files/IMG_1837-Photoroom.jpg?v=1741959092',
 ('ps2','Madagascar'):'https://cdn.awsli.com.br/800x800/138/138431/produto/15766175/7d2483b237.jpg',
 ('ps2','Ratchet & Clank'):'https://nosco.fra1.digitaloceanspaces.com/listings/2025/02/21/15/1176%2021022025%20201944%20%5BpIXj%5D.jpeg',
 ('ps4','Grand Theft Auto V'):'https://i5-mx.walmartimages.com/samsmx/images/product-images/img_large/000214194l.jpg',
 ('ps5','Call of Duty: Black Ops 7'):'https://www.nfm.com/on/demandware.static/-/Sites-nfm-master-catalog/default/dw87df00f6/images/068/91/68919281-1.jpg',
 ('ps5','Call of Duty: Black Ops 6'):'https://www.houseoffraser.co.uk/images/imgzoom/98/98794682_xxl.jpg',
 ('accessories','PlayStation VR2 + controllere și accesorii'):'https://www.tsoto.net/media/shop/products/14000/14299.jpg'
}

class ImageLinks(HTMLParser):
    def __init__(self): super().__init__();self.candidates=[]
    def handle_starttag(self,tag,attrs):
        if tag!='a':return
        d=dict(attrs)
        if 'iusc' not in (d.get('class') or '').split():return
        try:
            m=json.loads(unescape(d.get('m','{}')))
            u=m.get('murl') or m.get('turl');t=m.get('t') or m.get('desc') or ''
            if u:self.candidates.append((u,t,m.get('purl','')))
        except (json.JSONDecodeError,TypeError):pass

def get(url,timeout=11,headers=None,max_bytes=1400000):
    req=Request(url,headers={**HEADERS,**(headers or {})})
    with urlopen(req,timeout=timeout) as r:
        return r.read(max_bytes)

def normalize(s):
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return ' '.join(s.split())

def match_ratio(query,cand):
    a=normalize(query);b=normalize(cand)
    if not a or not b:return 0
    ax=[t for t in a.split() if t not in {'the','of','a','an','and','edition','collection','for','remastered','new','to','game'}]
    if not ax:return 0
    bwords=set(b.split())
    overlap=sum(w in bwords for w in ax)/len(ax)
    # Candidate includes extra platform, edition, store and packaging words.
    sub=SequenceMatcher(None,a,b).ratio()
    return overlap*.79+sub*.21

def looks_like_image_url(url):
    if not isinstance(url,str):return False
    x=urlparse(url)
    return x.scheme=='https' and bool(x.hostname) and x.hostname.lower() not in ('www.google.com','www.bing.com','duckduckgo.com') and len(url)<2000

def verify_image(url):
    """Check origin responds with image content; don't download image data into repo."""
    if not looks_like_image_url(url):return False
    try:
        req=Request(url,headers={**HEADERS,'Range':'bytes=0-4095'})
        with urlopen(req,timeout=9) as r:
            typ=r.headers.get('Content-Type','').lower().split(';')[0]
            chunk=r.read(48)
            if typ.startswith('image/'):
                return True
            return chunk.startswith((b'\xff\xd8',b'\x89PNG',b'RIFF',b'GIF8',b'\x00\x00\x00'))
    except (OSError,URLError,HTTPError,TimeoutError):return False

def discover_bing(platform,title):
    query=f'{PLABEL[platform]} {title} video game front cover box art'
    try:
        raw=get('https://www.bing.com/images/search?'+urlencode({'q':query,'form':'HDRSC3','first':1}),max_bytes=950000)
        doc=raw.decode('utf-8','replace')
        parser=ImageLinks();parser.feed(doc)
        candidates=[]
        for url,caption,source_page in parser.candidates[:24]:
            if not looks_like_image_url(url):continue
            score=match_ratio(title,caption+' '+urlparse(source_page).path.replace('-',' '))
            if score<.55:continue
            if platform in ('ps2','ps4','ps5','xbox','nintendo') and normalize(PLABEL[platform]).split()[0] in normalize(caption+' '+source_page):score+=.15
            if 'back cover' in normalize(caption) or 'screenshot' in normalize(caption):score-=.35
            if 'cover' in normalize(caption+' '+source_page):score+=.06
            candidates.append((score,url,source_page))
        candidates.sort(reverse=True)
        return [('Bing image search',u,src) for score,u,src in candidates[:6] if score>=.59]
    except Exception:return []

def discover_ddg(platform,title):
    query=f'{PLABEL[platform]} {title} box cover art game'
    try:
        page=get('https://duckduckgo.com/?'+urlencode({'q':query,'ia':'images'})).decode('utf-8','replace')
        m=re.search(r'(?:vqd=["\']?|vqd:["\']|vqd\s*=\s*["\'])([\d-]+)',page)
        if not m:return []
        data=json.loads(get('https://duckduckgo.com/i.js?'+urlencode({'l':'us-en','o':'json','q':query,'vqd':m.group(1),'f':',,,','p':'1'}), headers={'Referer':'https://duckduckgo.com/','Accept':'application/json'}))
        cand=[]
        for e in data.get('results',[])[:25]:
            url=e.get('image','');caption=e.get('title','')
            if not looks_like_image_url(url):continue
            score=match_ratio(title,caption+' '+urlparse(e.get('url','')).path.replace('-',' '))
            if 'cover' in normalize(caption):score+=.06
            if score>=.57:cand.append((score,url,e.get('url','')))
        cand.sort(reverse=True)
        return [('DuckDuckGo image search',u,src) for _,u,src in cand[:6]]
    except Exception:return []

def discover_steam(title):
    try:
        query=title.replace('’',"'")
        data=json.loads(get('https://store.steampowered.com/api/storesearch/?'+urlencode({'term':query,'cc':'us','l':'english'}),headers={'Referer':'https://store.steampowered.com/'},max_bytes=300000))
        games=[]
        for e in data.get('items',[])[:10]:
            s=match_ratio(title,e.get('name',''))
            if s>=.77 and SequenceMatcher(None,normalize(title),normalize(e.get('name',''))).ratio()>=.71:
                app=e.get('id')
                if isinstance(app,int):
                    url=f'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{app}/library_600x900.jpg'
                    games.append((s,url,f'https://store.steampowered.com/app/{app}/'))
        games.sort(reverse=True)
        return [('Steam official cover artwork',u,src) for _,u,src in games[:3]]
    except Exception:return []

@lru_cache(maxsize=4)
def libretro_index(platform):
    directory={'ps2':'Sony - PlayStation 2','ps4':'Sony - PlayStation 4','nintendo':'Nintendo - Nintendo Switch'}[platform]
    from urllib.parse import unquote
    url='https://thumbnails.libretro.com/'+quote(directory)+'/Named_Boxarts/'
    html=get(url,max_bytes=12000000).decode('utf-8','replace')
    names=re.findall(r'href="([^"]+\.png)"',html,re.IGNORECASE)
    return url,[(href,re.sub(r'\([^()]*\)','',unescape(unquote(href)).removesuffix('.png')).strip()) for href in names]

def discover_libretro(platform,title):
    if platform not in ('ps2','ps4','nintendo'):return []
    # A direct publicly hosted console cover database; do not guess image paths.
    try:
        url,names=libretro_index(platform)
        candidates=[]
        for href,stem in names:
            score=match_ratio(title,stem)
            if score>=.83:
                candidates.append((score,url+href))
        candidates.sort(reverse=True)
        return [('Libretro online box art',path,url) for _,path in candidates[:3]]
    except Exception:return []

def resolve_one(item):
    platform,title=item
    url=SEED.get((platform,title))
    if url and verify_image(url):return (platform,title,url,'Individually researched image','',True)
    # Prefer actual platform cover photographs. Steam is a final fallback because
    # artwork there might not have the physical console case header.
    sources=discover_bing(platform,title)
    if not sources:sources=discover_ddg(platform,title)
    if platform in ('ps2','ps4','nintendo'):
        sources+=discover_libretro(platform,title)
    for provider,url,page in sources:
        if verify_image(url):return (platform,title,url,provider,page,True)
    if platform in ('ps4','ps5','xbox','nintendo'):
        for provider,url,page in discover_steam(title):
            if verify_image(url):return (platform,title,url,provider,page,True)
    return (platform,title,'','Not verified','',False)

def patch_logo():
    target=ROOT/'media'/'play-spot-logo-v4.webp'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(ASSET.read_bytes())
    for name in ('index.html','ru.html'):
        p=ROOT/name
        s=p.read_text(encoding='utf-8')
        s=s.replace('src="media/play-spot-logo.webp"','src="media/play-spot-logo-v4.webp"')
        s=s.replace('width="240" height="65" decoding="async"','width="76" height="76" decoding="async"')
        s=s.replace('https://playstationspot.store/YOUR_LOGO.png','https://playstationspot.store/media/play-spot-logo-v4.webp')
        s=s.replace('href="YOUR_LOGO.png"','href="media/play-spot-logo-v4.webp"')
        s=s.replace('href="https://playstationspot.store/media/play-spot-logo-v4.webp" type="image/png"', 'href="https://playstationspot.store/media/play-spot-logo-v4.webp" type="image/webp"')
        if 'neon-v4.css' not in s:
            if s.count('</head>')!=1:raise ValueError(f'Unexpected head in {name}')
            s=s.replace('</head>','  <link rel="stylesheet" href="neon-v4.css?v=20261105">\n</head>',1)
        p.write_text(s,encoding='utf-8')
    (ROOT/'neon-v4.css').write_text('''/* Exact user-provided PlaySpotStore logo, no replacement wordmark. */
header .logo{display:flex;align-items:center;flex:0 0 auto;min-width:0;gap:0!important;text-decoration:none;}
header .logo img.brand-logo{display:block!important;width:76px!important;min-width:76px;height:76px!important;max-height:76px;object-fit:contain!important;object-position:center;filter:drop-shadow(0 0 9px rgba(74,255,210,.16));border-radius:50%;}
header{min-height:84px!important;}
:root{--header-height:84px;}
header nav ul li a{font-size:clamp(13px,1vw,15px)!important;}
@media(max-width:1050px){header nav ul{gap:10px!important;} header nav ul li a{font-size:12px!important;}}
@media(max-width:950px){header .logo img.brand-logo{width:68px!important;min-width:68px;height:68px!important;max-height:68px;} :root{--header-height:76px;}}
@media(max-width:550px){header .logo img.brand-logo{width:56px!important;min-width:56px;height:56px!important;max-height:56px;} :root{--header-height:64px;}}
''',encoding='utf-8')

def main():
    for name in ['index.html','ru.html','neon-v3.css']:
        if not (ROOT/name).is_file():raise SystemExit(f'Missing {name}. Run this from the existing PlaySpotStore root.')
    patch_logo()
    original={}
    pending=[]
    for cat in PLATFORMS:
        p=ROOT/'data'/f'{cat}.json'
        if not p.is_file():continue
        a=json.loads(p.read_text(encoding='utf-8'))
        original[cat]=a
        for x in a:
            if (x.get('image') or '').startswith('media/covers/'):
                pending.append((cat,x.get('title','')))
    print(f'Exact logo installed. Checking direct online cover URLs for {len(pending)} new entries...',flush=True)
    jobs={}
    workers=min(6,max(1,int(os.environ.get('PLAYSPOT_WORKERS','5'))))
    # Remote search engines may throttle; an unresolved record is never assigned
    # an invented URL or arbitrary unrelated image.
    with cf.ThreadPoolExecutor(max_workers=workers) as pool:
        future={pool.submit(resolve_one,key):key for key in pending}
        for n,fut in enumerate(cf.as_completed(future),1):
            k=future[fut]
            try:result=fut.result()
            except Exception:result=(k[0],k[1],'','Search error','',False)
            jobs[k]=result
            if n%20==0 or n==len(pending):
                found=sum(v[-1] for v in jobs.values())
                print(f'  Checked {n}/{len(pending)} | online matches: {found} | for review: {n-found}',flush=True)
    total_ok=0
    unresolved=[]
    import csv,io
    f=io.StringIO();writer=csv.writer(f)
    writer.writerow(['platform','id','product','status','source','source_page','image_url','google_images_search'])
    for cat,arr in original.items():
        updates=0
        for x in arr:
            if not (x.get('image') or '').startswith('media/covers/'):continue
            platform,title=cat,x['title']
            res=jobs.get((platform,title))
            if not res or not res[-1]:
                unresolved.append((cat,title,x.get('image','')))
                search_link='https://www.google.com/search?'+urlencode({'q': f'{PLABEL[cat]} {title} cover art product image', 'udm': '2'})
                writer.writerow([cat,x['id'],title,'NEEDS REVIEW','','','',search_link])
                continue
            _,_,url,source,page,_=res
            x['image']=url
            # Never fall back to cropped photos when external hosting fails.
            x['fallback_image']='media/play-spot-logo-v4.webp'
            x['image_source']=source
            if page:x['image_source_page']=page
            search_link='https://www.google.com/search?'+urlencode({'q': f'{PLABEL[cat]} {title} cover art product image', 'udm': '2'})
            writer.writerow([cat,x['id'],title,'ONLINE',source,page,url,search_link])
            updates+=1;total_ok+=1
        if updates:
            p=ROOT/'data'/f'{cat}.json'
            p.write_text(json.dumps(arr,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        # Mirror source URLs exactly into Russian product records with same ID.
        rp=ROOT/'data'/f'{cat}_ru.json'
        if rp.exists() and updates:
            rdata=json.loads(rp.read_text(encoding='utf-8'))
            byid={x['id']:x for x in arr}
            for x in rdata:
                ref=byid.get(x.get('id'))
                if ref and ref.get('image_source'):
                    x['image']=ref['image'];x['fallback_image']=ref['fallback_image'];x['image_source']=ref['image_source']
                    if ref.get('image_source_page'):x['image_source_page']=ref['image_source_page']
            rp.write_text(json.dumps(rdata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (ROOT/'online-image-audit.csv').write_text(f.getvalue(),encoding='utf-8')
    print(f'Image resolution complete: {total_ok} verified image URLs | {len(unresolved)} still require review.',flush=True)
    if unresolved:
        print('Existing cropped covers were left unchanged ONLY where no trustworthy live URL was available.',flush=True)
        print('See online-image-audit.csv to finish those manually. No unrelated URLs were invented.',flush=True)
    print('Both language pages now use your EXACT uploaded PlaySpotStore logo.',flush=True)
    return 0

if __name__=='__main__':sys.exit(main())
