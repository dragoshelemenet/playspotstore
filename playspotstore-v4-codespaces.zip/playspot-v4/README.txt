PLAYSPOTSTORE V4 — Exact brand logo + direct online product-cover image URLs

1. Upload the whole ZIP file to the root of your GitHub Codespace.
2. In Codespaces terminal:

   git pull --ff-only origin main && unzip -o playspotstore-v4-codespaces.zip -d . && bash playspot-v4/install.sh

What this does:
- Replaces the mismatched metallic header logo with the exact uploaded illustrated mint-circle PlaySpotStore logo.
- Also updates the favicon, social share preview, and header presentation in both language versions.
- Keeps all previously configured product data, descriptions, prices, promotion labels, GTA 6 section and PS VR2 video.
- Replaces the V3 photos cropped from inventory with direct external product image URLs, wherever matching online images can be checked.
- Includes a researched image URL list for Nintendo, Xbox, PS2, PS4 and PS5 entries; searches online image listings (Bing, DuckDuckGo, Libretro and Steam) for other product covers.
- Checks the direct image destination responds with an image MIME type before writing a URL.
- Mirrors the same matched URL into RO and RU JSON files.
- Writes online-image-audit.csv detailing exact matches, unresolved entries, and Google Images search links to finish those manually.

This is a best-effort online link finder, NOT a guarantee that all 196 cropped entries will be automatically matched. For safety, any unverified match is left unchanged rather than inventing an image or selecting the wrong game's cover. Review online-image-audit.csv after running. External retailer links can change or block hotlinking over time.

No product prices or inventory availability are changed.
