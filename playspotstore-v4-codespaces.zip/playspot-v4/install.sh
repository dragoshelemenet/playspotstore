#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [ "$(git branch --show-current)" != 'main' ]; then echo 'Switch to main first.';exit 1;fi
case "$(git remote get-url origin)" in *dragoshelemenet/playspotstore*) ;; *) echo 'Incorrect repository';exit 1;; esac
printf '\n=== PLAYSPOTSTORE V4 | EXACT LOGO + ONLINE COVERS ===\n'
git pull --ff-only origin main
if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
  echo 'Found existing uncommitted tracked changes. Commit or stash them first to avoid accidentally including them.'
  git status --short
  exit 1
fi
python3 playspot-v4/apply.py
# Stage only files this upgrade owns; don't commit unrelated personal changes.
git add -- index.html ru.html neon-v4.css media/play-spot-logo-v4.webp online-image-audit.csv data/*.json
if git diff --cached --quiet; then echo 'No new changes to commit.';exit 0;fi
git -c user.name='PlaySpotStore Update' -c user.email='playspotstore-update@users.noreply.github.com' commit -m 'Use exact PlaySpotStore logo and online product cover URLs'
git push origin main
printf '\nSUCCESS: changes pushed to GitHub main.\nCheck online-image-audit.csv for unresolved covers.\n'
