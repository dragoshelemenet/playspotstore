from pathlib import Path

ROOT=Path.cwd()
ICON='''<svg class="p11-delivery-icon" viewBox="0 0 48 48" fill="none" aria-hidden="true" focusable="false"><path d="M5 14h24v19H5z" stroke="currentColor" stroke-width="2.8"/><path d="M29 19h8l6 8v6H29V19Z" stroke="currentColor" stroke-width="2.8"/><path d="M10 33h31" stroke="currentColor" stroke-width="2.8"/><circle cx="14" cy="34" r="4.1" fill="#103b37" stroke="currentColor" stroke-width="2.8"/><circle cx="36" cy="34" r="4.1" fill="#103b37" stroke="currentColor" stroke-width="2.8"/><path d="M10 9h14M7 5h11" stroke="currentColor" stroke-width="2.8"/></svg>'''
for file in ('index.html','ru.html'):
 p=ROOT/file
 if not p.is_file(): raise SystemExit(f'Missing {file}; run from repository root')
 s=p.read_text(encoding='utf-8')
 old='<i class="bx bx-truck"></i>'
 if old in s:
  assert s.count(old)==1,(file,'multiple truck icons found; aborting')
  s=s.replace(old,ICON,1)
 elif ICON not in s:
  raise SystemExit(f'AWB icon marker not found in {file}; no changes applied')
 # Reset the old global carousel index when a different product is opened.
 reset='  showSlide(currentSlideIndex);\n'
 if reset in s:
  assert s.count(reset)==1,(file,'carousel reset has multiple candidates')
  s=s.replace(reset,'  currentSlideIndex = 0;\n  showSlide(currentSlideIndex);\n',1)
 # CSS link is intentionally the final stylesheet in the HEAD.
 link='  <link rel="stylesheet" href="playspot-v11.css?v=20261105a">\n'
 if 'playspot-v11.css' not in s:
  if '</head>' not in s:raise SystemExit(f'No HTML head found in {file}')
  s=s.replace('</head>',link+'</head>',1)
 p.write_text(s,encoding='utf-8')
 print(f'Updated {file}: AWB icon, product carousel reset, stylesheet')
