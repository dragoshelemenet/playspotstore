#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
printf '\n=== PLAYSPOTSTORE V11 — AWB ICON + PRODUCT DETAIL ===\n'
if [[ "$(git branch --show-current)" != main ]]; then
  echo 'Please switch to main first: git switch main' >&2
  exit 1
fi
if ! git diff --quiet HEAD -- index.html ru.html playspot-v11.css; then
  echo 'Website files contain uncommitted changes. Commit or stash those edits before installing.' >&2
  exit 1
fi
if [[ ! -f playspot-v11/apply.py || ! -f playspot-v11/playspot-v11.css ]]; then
  echo 'Installer files missing. Unzip V11 into the repository root.' >&2
  exit 1
fi
printf 'Pulling main first...\n'
git pull --ff-only origin main
python3 playspot-v11/apply.py
cp playspot-v11/playspot-v11.css ./playspot-v11.css
git add -- index.html ru.html playspot-v11.css
if git diff --cached --quiet -- index.html ru.html playspot-v11.css; then
  echo 'V11 already installed. Nothing to commit.'
  exit 0
fi
git commit -m 'Design: fix AWB icon and polish product detail dialog' -- index.html ru.html playspot-v11.css
git push origin main
printf '\nSUCCESS: PlaySpotStore V11 pushed to main.\n'
