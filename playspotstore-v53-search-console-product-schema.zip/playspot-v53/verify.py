#!/usr/bin/env python3
"""Verify every published RO/RU product's canonical and Google JSON-LD eligibility."""
from __future__ import annotations
import argparse
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

import patch

SITE = 'https://playspotstore.online'
XNS = {'s': 'http://www.sitemaps.org/schemas/sitemap/0.9'}


def verify(root: Path) -> None:
    root = root.resolve()
    index = json.loads((root / 'playspot-v49/slug-index.json').read_text(encoding='utf-8'))
    sitemap = ET.parse(root / 'sitemap.xml')
    sitemap_urls = {n.find('s:loc', XNS).text for n in sitemap.findall('s:url', XNS)}
    product_total = sum(len(json.loads((root / 'data' / f'{cat}.json').read_text(encoding='utf-8')))
                        for cat in patch.CATS)
    expected_urls = 2 * product_total + 18  # 2 home, 14 categories, 2 Moldova guides.
    assert len(sitemap_urls) == expected_urls, ('Sitemap URL count changed', len(sitemap_urls))
    counts = {'Product': 0, 'WebPage': 0}
    by_language = {'ro': 0, 'ru': 0}

    for cat in patch.CATS:
        folder = 'console' if cat == 'consoles' else cat
        for lang in ('ro', 'ru'):
            data = json.loads((root / 'data' / f'{cat}{"_ru" if lang == "ru" else ""}.json').read_text(encoding='utf-8'))
            for item in data:
                rel = Path('ru/produse' if lang == 'ru' else 'produse') / folder / index[cat][str(item['id'])]
                url = SITE + '/' + rel.as_posix()
                source = (root / rel).read_text(encoding='utf-8')
                assert url in sitemap_urls, ('Missing from sitemap', rel)
                assert source.count(f'<link rel="canonical" href="{url}">') == 1, ('Canonical', rel)
                matches = list(patch.JSON_LD.finditer(source))
                assert len(matches) == 1, ('Exactly one JSON-LD script needed', rel)
                graph = json.loads(matches[0].group(2))['@graph']
                assert len(graph) >= 2 and graph[1]['@type'] == 'BreadcrumbList', ('Breadcrumbs', rel)
                entity = graph[0]
                assert entity['url'] == url and entity['name'] == item['title'], ('Identity', rel)
                assert entity['description'] == item['description'], ('Catalog description', rel)
                price = patch.price_value(item.get('price'))
                if price is None:
                    assert entity['@type'] == 'WebPage', ('Unpriced item has ineligible Product markup', rel)
                    assert entity['about']['@type'] == 'Thing' and entity['about']['identifier'] == str(item['id']), rel
                    assert entity['inLanguage'] == lang, rel
                    assert 'offers' not in entity and 'aggregateRating' not in entity and 'review' not in entity, rel
                    counts['WebPage'] += 1
                else:
                    assert entity['@type'] == 'Product', ('Priced item lost Product markup', rel)
                    assert entity['sku'] == str(item['id']) and entity['@id'] == url + '#product', rel
                    offer = entity['offers']
                    assert offer['@type'] == 'Offer' and offer['url'] == url, rel
                    assert offer['price'] == price and offer['priceCurrency'] == 'MDL', rel
                    assert offer['seller']['name'] == 'PlaySpotStore' and offer['seller']['url'] == SITE + '/', rel
                    assert 'aggregateRating' not in entity and 'review' not in entity, rel
                    verified = item.get('verified_schema') or {}
                    if verified.get('availability'):
                        assert offer['availability'] == 'https://schema.org/' + verified['availability'], rel
                    else:
                        assert 'availability' not in offer, ('Unverified inventory', rel)
                    counts['Product'] += 1
                by_language[lang] += 1

    assert by_language['ro'] == by_language['ru'] == product_total, by_language
    assert sum(counts.values()) == 2 * product_total, counts
    patch.run(root, check=True)
    print(f"V53 VALID: {counts['Product']} Product+Offer pages, {counts['WebPage']} unpriced catalog pages, "
          f'{expected_urls} unchanged sitemap URLs, truthful data, canonical links, no invented reviews/stock.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='.')
    args = parser.parse_args()
    verify(Path(args.root))
