#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname -- "$SCRIPT_DIR")"
cd "$REPO_ROOT"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "ERROR: this installer must run inside the PlaySpotStore Codespace." >&2
  exit 1
fi
if [[ -n "$(git diff --cached --name-only)" ]]; then
  echo "ERROR: staged edits already exist. Commit or unstage them before installing V53." >&2
  exit 1
fi

# Do not silently overwrite any preexisting changes to product pages or generator.
while IFS= read -r changed; do
  case "$changed" in
    produse/*|ru/produse/*|playspot-v29/generate.py|playspot-v29/validate.py|playspot-v49/validate.py)
      echo "ERROR: existing edit in $changed. Preserve/commit it before V53." >&2
      exit 1
      ;;
  esac
done < <(git diff --name-only)

python3 -B playspot-v53/tests.py
python3 -B playspot-v53/patch.py --root .
python3 -B playspot-v53/verify.py --root .
python3 -B playspot-v29/validate.py --root .
python3 -B playspot-v49/validate.py --root .
python3 -B playspot-v50/validate.py --root .
git diff --check

git add -- playspot-v53/patch.py playspot-v53/verify.py \
  playspot-v53/install.sh playspot-v53/README.txt playspot-v53/tests.py \
  playspot-v29/generate.py playspot-v29/validate.py playspot-v49/validate.py
git add -u -- produse ru/produse

if git diff --cached --quiet; then
  echo "V53 already installed; no changes to push."
  exit 0
fi

git commit -m "Fix misleading Product markup for price-on-request pages (V53)"
git push origin main
echo "V53 pushed. Google can take days or weeks to recrawl."
