#!/usr/bin/env python3
"""Self-contained regression tests; do not need GitHub or site deployment."""
from __future__ import annotations
import json
import unittest

import patch

URL = 'https://playspotstore.online/produse/ps4/example.html'
ITEM = {'id': 'ps4-test-1', 'title': 'Example Game',
        'description': 'An actual catalog description.',
        'price': 'Concretizează prin contact',
        'availability': 'confirm_by_contact'}


def fixture(price: bool = False) -> str:
    entity = {
        '@type': 'Product', 'name': ITEM['title'], 'sku': ITEM['id'],
        'url': URL, 'description': ITEM['description'],
        'image': ['https://example.org/cover.jpg'], 'category': 'Jocuri PS4',
    }
    if price:
        entity['offers'] = {
            '@type': 'Offer', 'url': URL, 'price': 400.0,
            'priceCurrency': 'MDL',
        }
    document = {'@context': 'https://schema.org', '@graph': [entity, {
        '@type': 'BreadcrumbList', 'itemListElement': [],
    }]}
    return '<html><script type="application/ld+json">' + json.dumps(document) + '</script></html>'


def graph(source: str) -> list:
    return json.loads(patch.JSON_LD.search(source).group(2))['@graph']


class StructuredDataTests(unittest.TestCase):
    def test_price_by_request_is_webpage_without_product_snippet(self) -> None:
        s = patch.rewrite_document(fixture(), ITEM, 'ro', URL)
        self.assertEqual(graph(s)[0]['@type'], 'WebPage')
        self.assertNotIn('offers', graph(s)[0])
        self.assertEqual(graph(s)[0]['about']['identifier'], ITEM['id'])
        self.assertEqual(graph(s)[1]['@type'], 'BreadcrumbList')
        self.assertEqual(s, patch.rewrite_document(s, ITEM, 'ro', URL))

    def test_priced_is_product_with_real_offer_not_fake_stock(self) -> None:
        item = {**ITEM, 'price': '400 MDL'}
        s = patch.rewrite_document(fixture(price=True), item, 'ro', URL)
        entity = graph(s)[0]
        self.assertEqual(entity['@type'], 'Product')
        self.assertEqual(entity['offers']['price'], 400.0)
        self.assertEqual(entity['offers']['priceCurrency'], 'MDL')
        self.assertNotIn('availability', entity['offers'])
        self.assertNotIn('review', entity)
        self.assertEqual(s, patch.rewrite_document(s, item, 'ro', URL))

    def test_verified_fields_are_opt_in(self) -> None:
        item = {**ITEM, 'price': '400 MDL', 'verified_schema': {
            'brand': 'Real verified maker', 'gtin13': '1234567890123',
            'availability': 'OutOfStock',
        }}
        entity = graph(patch.rewrite_document(fixture(price=True), item, 'ro', URL))[0]
        self.assertEqual(entity['brand']['name'], 'Real verified maker')
        self.assertEqual(entity['gtin13'], '1234567890123')
        self.assertEqual(entity['offers']['availability'], 'https://schema.org/OutOfStock')

    def test_new_confirmed_price_can_restore_product_markup(self) -> None:
        unpriced = patch.rewrite_document(fixture(), ITEM, 'ro', URL)
        item = {**ITEM, 'price': '450 MDL'}
        changed = patch.rewrite_document(unpriced, item, 'ro', URL)
        self.assertEqual(graph(changed)[0]['@type'], 'Product')
        self.assertEqual(graph(changed)[0]['offers']['price'], 450.0)
        self.assertEqual(changed, patch.rewrite_document(changed, item, 'ro', URL))

    def test_identity_mismatch_fails_before_any_write(self) -> None:
        with self.assertRaisesRegex(ValueError, 'Product title mismatch'):
            patch.rewrite_document(fixture(), {**ITEM, 'title': 'Changed'}, 'ro', URL)

    def test_invalid_price_never_becomes_zero_offer(self) -> None:
        for raw in ('0 MDL', 'Preț la cerere', '400', '400 RON', '-10 MDL'):
            self.assertIsNone(patch.price_value(raw))


if __name__ == '__main__':
    unittest.main()
