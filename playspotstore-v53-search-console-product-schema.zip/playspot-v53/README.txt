PLAYSPOTSTORE V53 — GOOGLE SEARCH CONSOLE PRODUCT SCHEMA
13 November 2026

WHY GOOGLE SENT THE EMAIL
279 products in RO + RU = 558 product pages. The source catalog has 76
products with a real positive price in MDL, and 203 labelled "price by
contact". Previously all 558 pages emitted Product schema, but 406
unpriced pages had none of the three Google Product snippet eligibility
fields: offers, review, aggregateRating. Search Console reported these as
invalid Product rich-result candidates.

CHANGES
- Keep correctly priced products as Product with real Offer (152 language
  pages), accurate MDL price, same canonical URL, and store as seller.
- Treat unpriced listings as WebPage + BreadcrumbList (406 language pages).
  They can be indexed normally but cannot show a Product rich result until
  the price is confirmed. This removes the invalid Product markup rather
  than making up an offer, review or rating.
- Preserve page content, full indexability, SEO metadata, hreflang, 576
  sitemap URLs, category links, and URLs. No canonical migration.
- Make the generator invoke V53 after any regeneration. Update V29/V49
  validators for price-aware structured data, keep V50 quality checks.
- Optional: to publish separately verified data later, set per-item JSON
  field "verified_schema": {"brand":"Actual manufacturer","availability":"InStock"}.
  Only add factual, checked fields; in-stock is NOT presumed by a price.
  Supported item identifiers: gtin8, gtin12, gtin13, gtin14, mpn.

NOT AUTOMATICALLY RESOLVED (NEEDS REAL MERCHANT FACTS)
- availability: the catalog currently does not verify current stock.
- shippingDetails: cost and arrival time vary and are confirmed with buyer.
- hasMerchantReturnPolicy: store policy is not supplied to us.
- brand/GTIN: manufacturer/GTIN are not present in the product JSON source.
- review/aggregateRating: no real customer review data available. These
  are optional on pages already supplying a valid Offer.
- Excluded "alternate page with proper canonical" reports need example
  affected URLs from Search Console. Some excluded duplicates are expected.

INSTALL AFTER UPLOADING ZIP TO THE REPO MAIN ROOT
git pull --ff-only origin main && unzip -o playspotstore-v53-search-console-product-schema.zip -d . && bash playspot-v53/install.sh

AFTER DEPLOY
1. Confirm that the deployment completed.
2. Google Rich Results Test: test one priced page and one unpriced page.
   Priced pages should report Product; unpriced pages should not report an
   invalid Product rich result.
3. Search Console > Shopping / Products: Validate Fix when live markup
   matches. Past crawl errors stay visible until Google recrawls pages.

Truthful, idempotent update; no hard-coded dummy prices or fake signals.
