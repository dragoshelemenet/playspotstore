#!/usr/bin/env python3
"""V53: truthful, repeat-safe Google product structured data.

Known positive MDL price -> Product + Offer. Price by contact -> WebPage.
No invented ratings, inventory, shipping prices, returns or brand identifiers.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

SITE = 'https://playspotstore.online'
CATS = ('ps2', 'ps4', 'ps5', 'nintendo', 'xbox', 'consoles', 'accessories')
JSON_LD = re.compile(r'(<script type="application/ld\+json">)(.*?)(</script>)', re.S)
HOOK = '''    # P53_TRUTHFUL_PRODUCT_SCHEMA: reapply eligibility rules after regeneration.
    addon53 = root / 'playspot-v53' / 'patch.py'
    if addon53.is_file(): subprocess.run([sys.executable, '-B', str(addon53), '--root', str(root)], check=True)
'''
ANCHOR = "    print(f'✅ Generated {total*2} product pages"


def price_value(value: object) -> float | None:
    """Exact semantics of the V29 generator, not arbitrary digit extraction."""
    text = ' '.join(str(value or '').split())
    if not re.fullmatch(r'[\d,.]+\s+MDL', text, re.I):
        return None
    try:
        number = float(text[:-3].strip().replace(',', ''))
    except ValueError:
        return None
    if not 0 < number < 100000000:
        return None
    return round(number, 2)


def rewrite_document(source: str, item: dict, lang: str, expected_url: str) -> str:
    matches = list(JSON_LD.finditer(source))
    if len(matches) != 1:
        raise ValueError(f'Expected exactly one JSON-LD script: {expected_url}')
    match = matches[0]
    document = json.loads(match.group(2))
    graph = document.get('@graph')
    if not isinstance(graph, list) or len(graph) < 2:
        raise ValueError('Missing Product/WebPage and breadcrumb graph: ' + expected_url)
    entity = graph[0]
    if entity.get('@type') not in ('Product', 'WebPage'):
        raise ValueError('Unexpected schema entity for ' + expected_url)
    if entity.get('url') != expected_url:
        raise ValueError('Schema URL does not match canonical URL: ' + expected_url)
    if not any(e.get('@type') == 'BreadcrumbList' for e in graph[1:]):
        raise ValueError('Missing original breadcrumbs for ' + expected_url)
    if not isinstance(item.get('title'), str) or item['title'] != entity.get('name'):
        raise ValueError('Product title mismatch; refusing silent overwrite: ' + expected_url)
    if entity['@type'] == 'Product' and str(entity.get('sku')) != str(item['id']):
        raise ValueError('SKU mismatch; refusing silent overwrite: ' + expected_url)

    price = price_value(item.get('price'))
    if price is not None:
        # Priced product is eligible for Google Product snippets. Availability is
        # deliberately omitted because source JSON does not confirm stock.
        if entity['@type'] == 'WebPage':
            about = entity.get('about', {})
            if about.get('identifier') != str(item['id']):
                raise ValueError('WebPage identifier mismatch: ' + expected_url)
            entity = {
                '@type': 'Product', 'name': item['title'], 'sku': str(item['id']),
                'url': expected_url, 'description': entity['description'],
                'image': [entity['primaryImageOfPage']['url']],
                'category': item.get('seo_category_label', ''),
            }
            if not entity['category']:
                entity.pop('category')
        entity['@id'] = expected_url + '#product'
        entity['offers'] = {
            '@type': 'Offer', 'url': expected_url,
            'price': price, 'priceCurrency': 'MDL',
            'seller': {'@type': 'Organization', 'name': 'PlaySpotStore', 'url': SITE + '/'},
        }
        # Only explicit, externally verified facts should be added when supplied.
        # Category/platform names are NOT manufacturer brands or GTINs.
        verified = item.get('verified_schema') or {}
        if verified:
            if not isinstance(verified, dict):
                raise ValueError('verified_schema must be an object: ' + expected_url)
            brand = verified.get('brand')
            if brand:
                entity['brand'] = {'@type': 'Brand', 'name': str(brand)}
            for key in ('gtin8', 'gtin12', 'gtin13', 'gtin14', 'mpn'):
                if verified.get(key):
                    entity[key] = str(verified[key])
            availability = verified.get('availability')
            if availability:
                allowed = ('InStock', 'OutOfStock', 'PreOrder', 'BackOrder', 'SoldOut')
                if availability not in allowed:
                    raise ValueError('Unrecognized verified availability: ' + expected_url)
                entity['offers']['availability'] = 'https://schema.org/' + availability
    else:
        # A price-on-request catalog listing is still a useful indexable HTML
        # page, but it is not a valid Google Product rich-result candidate.
        if entity['@type'] == 'Product':
            pictures = entity.get('image', [])
            if not isinstance(pictures, list) or not pictures:
                raise ValueError('Missing product image: ' + expected_url)
            description = entity.get('description', '')
            entity = {
                '@type': 'WebPage', '@id': expected_url + '#webpage',
                'url': expected_url, 'name': entity['name'],
                'description': description, 'inLanguage': lang,
                'primaryImageOfPage': {'@type': 'ImageObject', 'url': pictures[0]},
                'about': {'@type': 'Thing', 'name': entity['name'],
                          'identifier': str(item['id'])},
                'isPartOf': {'@type': 'WebSite', 'name': 'PlaySpotStore', 'url': SITE + '/'},
            }
        if entity.get('@type') != 'WebPage' or 'offers' in entity:
            raise ValueError('Unpriced item must use a WebPage entity: ' + expected_url)
    graph[0] = entity
    serialized = json.dumps(document, ensure_ascii=False, separators=(',', ':'))
    serialized = serialized.replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    return source[:match.start(2)] + serialized + source[match.end(2):]


def plan(root: Path) -> tuple[dict[Path, str], dict[str, int]]:
    root = root.resolve()
    slugs = json.loads((root / 'playspot-v49' / 'slug-index.json').read_text(encoding='utf-8'))
    changes: dict[Path, str] = {}
    counts = {'priced': 0, 'unpriced': 0, 'pages': 0}
    for cat in CATS:
        folder = 'console' if cat == 'consoles' else cat
        for lang in ('ro', 'ru'):
            file = root / 'data' / f'{cat}{"_ru" if lang == "ru" else ""}.json'
            for item in json.loads(file.read_text(encoding='utf-8')):
                rel = Path('ru/produse' if lang == 'ru' else 'produse') / folder / slugs[cat][str(item['id'])]
                target = root / rel
                original = target.read_text(encoding='utf-8')
                # Verify the actual canonical too; do not create split signals.
                canonical = f'<link rel="canonical" href="{SITE}/{rel.as_posix()}">'
                if original.count(canonical) != 1:
                    raise ValueError('Canonical mismatch: ' + str(rel))
                updated = rewrite_document(original, item, lang, SITE + '/' + rel.as_posix())
                if updated != original:
                    changes[target] = updated
                counts['priced' if price_value(item.get('price')) is not None else 'unpriced'] += 1
                counts['pages'] += 1
    generator = root / 'playspot-v29' / 'generate.py'
    code = generator.read_text(encoding='utf-8')
    if 'P53_TRUTHFUL_PRODUCT_SCHEMA' not in code:
        if code.count(ANCHOR) != 1 or 'P50_SEO_QUALITY_HOOK' not in code:
            raise ValueError('Unexpected old generator; cannot add V53 hook safely')
        changes[generator] = code.replace(ANCHOR, HOOK + ANCHOR, 1)
    for name in ('playspot-v29/validate.py', 'playspot-v49/validate.py'):
        validator = root / name
        code = validator.read_text(encoding='utf-8')
        if name.endswith('v29/validate.py') and 'V53_SCHEMA_PAGE_TYPE' not in code:
            old = """                p=graph[0]
                assert p['@type']=='Product',f'Wrong schema: {path}'
                assert 'availability' not in p,f'Fabricated inventory status: {path}'
                if 'offers' in p:
                    offer=p['offers']
                    assert offer['priceCurrency']=='MDL' and isinstance(offer['price'],(int,float)) and offer['price']>0
"""
            new = """                # V53_SCHEMA_PAGE_TYPE: unpriced listings are WebPage, not rich-result Product.
                p=graph[0]
                assert p['@type'] in ('Product','WebPage'),f'Wrong schema: {path}'
                if p['@type']=='Product':
                    assert 'offers' in p,f'Unpriced Product rich-result candidate: {path}'
                    offer=p['offers']
                    assert offer['priceCurrency']=='MDL' and isinstance(offer['price'],(int,float)) and offer['price']>0
                else:
                    assert 'offers' not in p and p.get('inLanguage') in ('ro','ru')
"""
            if code.count(old) != 1:
                raise ValueError('Unexpected V29 validator; refusing edit')
            changes[validator] = code.replace(old, new)
        if name.endswith('v49/validate.py') and 'V53_SCHEMA_PAGE_TYPE' not in code:
            old = """                product=next(p for p in graph if p.get('@type')=='Product')
                assert product['sku']==pid and product['url']==SITE+rel,rel
                assert product['name']==p['title'] and product['description']==p['description'],('Product data changed',rel)
                assert 'aggregateRating' not in product and 'availability' not in product,rel
"""
            new = """                # V53_SCHEMA_PAGE_TYPE: price on request has no Product rich result.
                entity=graph[0]
                assert entity['url']==SITE+rel,rel
                assert entity['name']==p['title'] and entity['description']==p['description'],('Page data changed',rel)
                price_known=bool(re.fullmatch(r'[\\d,.]+\\s+MDL',str(p.get('price','')).strip(),re.I))
                if price_known:
                    assert entity['@type']=='Product' and entity['sku']==pid and 'offers' in entity,rel
                    assert entity['offers']['price']>0 and entity['offers']['priceCurrency']=='MDL',rel
                    assert 'aggregateRating' not in entity,rel
                else:
                    assert entity['@type']=='WebPage' and entity['about']['identifier']==pid,rel
                    assert 'offers' not in entity and 'aggregateRating' not in entity,rel
"""
            if code.count(old) != 1:
                raise ValueError('Unexpected V49 validator; refusing edit')
            changes[validator] = code.replace(old, new)
    return changes, counts


def run(root: Path, check: bool = False) -> None:
    changes, counts = plan(root)
    if check:
        if changes:
            raise AssertionError(f'V53 pending edits: {len(changes)} files')
        print('V53 repeat-safe:', counts)
        return
    for path, content in changes.items():
        path.write_text(content, encoding='utf-8')
    print(f"V53: {counts['priced']} priced Product+Offer pages, "
          f"{counts['unpriced']} WebPage listings, {counts['pages']} product pages; "
          f"{len(changes)} changed files")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='.')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    run(Path(args.root), args.check)
