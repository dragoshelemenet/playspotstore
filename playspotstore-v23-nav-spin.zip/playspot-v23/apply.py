#!/usr/bin/env python3
"""Idempotently patch the PlaySpotStore RO/RU navigation, V23 assets."""
from pathlib import Path
import re

root=Path.cwd()
for filename in ('index.html','ru.html'):
    path=root/filename
    if not path.is_file():raise SystemExit(f'ERROR: Missing {filename}; start in PlaySpotStore repository root')
    s=path.read_text(encoding='utf-8')
    if 'id="main-menu"' not in s or 'id="how-to-order"' not in s or 'id="btn-unavailable"' not in s:
        raise SystemExit(f'ERROR: Expected navigation/order section missing in {filename}; no change')
    if 'playspot-v22.js' not in s or 'playspot-v16.js' not in s:
        raise SystemExit(f'ERROR: V22/V16 missing in {filename}. Install prior updates first.')
    original=s
    isru=filename=='ru.html'
    how='КАК ЗАКАЗАТЬ' if isru else 'CUM COMAND'
    absent='ЕСЛИ ИГРЫ НЕТ В НАЛИЧИИ?' if isru else 'DACĂ JOCUL NU E DISPONIBIL?'
    # Place desktop/mobile link directly after the contact item.
    if 'class="p23-menu-how"' not in s:
        match=re.search(r'(<ul id="main-menu">\s*<li>\s*<a href="#contact">[^<]+</a>\s*</li>)',s)
        if not match:raise SystemExit(f'ERROR: CONTACT menu position not found in {filename}. No change.')
        s=s[:match.end()]+f'<li class="p23-menu-how"><a href="#how-to-order">{how}</a></li>'+s[match.end():]
    # The unavailable shortcut is mobile only, before the mobile search input.
    if 'data-p23-unavailable' not in s:
        marker='<li class="mobile-search-bar">'
        pos=s.find(marker,s.index('<ul id="main-menu">'))
        if pos<0:raise SystemExit(f'ERROR: Mobile search menu marker missing from {filename}. No change.')
        s=s[:pos]+f'<li class="p23-mobile-only"><a href="#how-to-order" data-p23-unavailable>{absent}</a></li>'+s[pos:]
    if 'playspot-v23.css' not in s:
        s=s.replace('</head>','  <link rel="stylesheet" href="playspot-v23.css?v=20261108-v23a">\n</head>',1)
    if 'playspot-v23.js' not in s:
        s=s.replace('</body>','  <script defer src="playspot-v23.js?v=20261108-v23a"></script>\n</body>',1)
    path.write_text(s,encoding='utf-8')
    print(f'{filename}: '+('updated' if s!=original else 'already installed'))
