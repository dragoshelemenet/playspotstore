PLAYSPOTSTORE V23
=================
What's new:
- Adds CUM COMAND / КАК ЗАКАЗАТЬ to desktop and mobile navigation; scrolls to #how-to-order.
- Adds DACĂ JOCUL NU E DISPONIBIL? / ЕСЛИ ИГРЫ НЕТ В НАЛИЧИИ? only in hamburger menu; opens the existing unavailable-game modal.
- Displays the existing V22 SPIN & WIN button on desktop too, in free header space. Mobile layout unchanged.
- Makes OFERTĂ LIMITATĂ / ОГРАНИЧЕННАЯ АКЦИЯ on the floating bar open the wheel by click or keyboard.
- Adds two small slow-moving glowing dots on the perimeter of the floating bar. Respects reduced-motion preferences.
- Preserves V14-V22 code/game selection/prize/expiry and existing TikTok gallery.

INSTALLATION: Upload playspotstore-v23-nav-spin.zip to your Codespaces repository root, then:
 git pull --ff-only origin main && unzip -o playspotstore-v23-nav-spin.zip -d . && bash playspot-v23/install.sh

Only modifies index.html and ru.html and adds playspot-v23.css / playspot-v23.js.
Installer pushes a commit to main.
