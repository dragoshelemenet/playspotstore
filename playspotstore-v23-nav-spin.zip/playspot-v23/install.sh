#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [ "$(git branch --show-current)" != main ]; then
  echo 'ERROR: Switch to the main branch first.' >&2;exit 1
fi
git pull --ff-only origin main
python3 playspot-v23/apply.py
install -m 644 playspot-v23/playspot-v23.css ./playspot-v23.css
install -m 644 playspot-v23/playspot-v23.js ./playspot-v23.js
git add index.html ru.html playspot-v23.css playspot-v23.js
if git diff --cached --quiet; then
  echo 'V23 already installed; nothing to commit.'
else
  git commit -m 'V23: add order navigation, desktop Spin and subtle edge lights'
  git push origin main
fi
echo 'SUCCESS: PlaySpotStore V23 is installed.'
