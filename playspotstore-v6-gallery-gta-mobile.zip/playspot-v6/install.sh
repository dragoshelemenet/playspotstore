#!/usr/bin/env bash
# PlaySpotStore V6: GTA 6 mobile refinements + zoomable stock gallery.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
echo '=== PLAYSPOTSTORE V6: GALLERY + GTA 6 MOBILE ==='
if [[ "$(git branch --show-current)" != "main" ]]; then
  echo 'ERROR: Please switch to the main branch first (git switch main).' >&2
  exit 1
fi
# The updater must always pull latest main before changing files.
echo 'Pulling latest GitHub main...'
git pull --ff-only origin main
if ! git diff --quiet -- index.html ru.html; then
  echo 'ERROR: index.html or ru.html has uncommitted changes. Commit or stash before updating.' >&2
  exit 1
fi
for page in index.html ru.html; do
  if [[ ! -f "$page" ]] || ! grep -q 'id="gta6"' "$page" || ! grep -q 'class="p3-photo-grid"' "$page"; then
    echo "ERROR: Expected V3 GTA/gallery markup missing in $page; update stopped safely." >&2
    exit 1
  fi
done
mkdir -p .
cp playspot-v6/playspot-v6.css ./playspot-v6.css
cp playspot-v6/playspot-v6.js ./playspot-v6.js
python3 - <<'PY'
from pathlib import Path
import re
css='  <link rel="stylesheet" href="playspot-v6.css?v=20261105a">'
js='  <script defer src="playspot-v6.js?v=20261105a"></script>'
for page in ('index.html','ru.html'):
    path=Path(page)
    html=path.read_text(encoding='utf-8')
    if html.count('</head>')!=1 or html.count('</body>')!=1:
        raise SystemExit(f'Invalid HTML head/body structure in {page}; stopped safely')
    # Re-running only refreshes the assets; never double-inject references.
    html=re.sub(r'(?m)^[ \t]*<link\b[^>]*href="playspot-v6\.css[^>]*>[ \t]*\n?', '', html, flags=re.M)
    html=re.sub(r'(?m)^[ \t]*<script\b[^>]*src="playspot-v6\.js[^>]*></script>[ \t]*\n?', '', html, flags=re.M)
    html=html.replace('</head>',css+'\n</head>',1)
    html=html.replace('</body>',js+'\n</body>',1)
    path.write_text(html,encoding='utf-8')
    print(f'Updated {page}: mobile GTA layout and gallery lightbox')
PY
# Avoid adding untracked user files or installer ZIP to the commit.
git add index.html ru.html playspot-v6.css playspot-v6.js
if git diff --cached --quiet; then
  echo 'Already installed. No changes to commit.'
  exit 0
fi
git diff --cached --check
git -c user.name="PlaySpotStore Update" -c user.email="playspotstore-update@users.noreply.github.com" commit -m "Improve GTA 6 mobile layout and add full-screen inventory gallery"
git push origin main
echo 'SUCCESS. V6 pushed to GitHub main.'
