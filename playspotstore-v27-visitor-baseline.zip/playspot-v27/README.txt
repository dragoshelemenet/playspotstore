PlaySpotStore V27 — 2026 BASELINE + RECORDED VISITS (RO + RU)

Upload the ZIP in the repository root. Then run:
  git pull --ff-only origin main && unzip -o playspotstore-v27-visitor-baseline.zip -d . && bash playspot-v27/install.sh

- Counter starts with a PRESET, MANUALLY ENTERED baseline of 330,012 for 2026. This is NOT independently measured historical traffic.
- The displayed total is: 330012 + the CountAPI value for genuinely recorded new browsers.
- Uses the SAME backend key and localStorage marker as V26; it does NOT reset real visits already counted by V26.
- First new browser at production domain triggers +1. Reloads, switches RO/RU and repeat visits from the same browser do not register additional visits (unless site storage is cleared).
- API is public, not tamperproof, and users with multiple browsers can inflate it. This is approximate unique browsers, not verified unique persons.
- If the backend is unavailable, shows ONLY the labelled preset 330012 with an explicit temporary availability warning; it never invents recorded visits.
- No production HTTP traffic is made during installation/tests.
- Supports both scenarios: V26 installed already or V25 without V26.
