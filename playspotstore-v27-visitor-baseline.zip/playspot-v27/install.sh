#!/usr/bin/env bash
set -euo pipefail
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
 echo 'ERROR: run this installer from the PlaySpotStore repository root' >&2
 exit 1
fi
git pull --ff-only origin main
python3 playspot-v27/apply.py
git add index.html ru.html playspot-v27.css playspot-v27.js
if git diff --cached --quiet; then
 echo 'V27 is already installed; nothing to commit.'
else
 git commit -m 'V27: preset 2026 visitor baseline plus server-counted visits'
 git push origin main
fi
echo 'SUCCESS: V27 installed (2026 baseline 330012 plus visits recorded from the counter API)'
