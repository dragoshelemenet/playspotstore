#!/usr/bin/env python3
"""Idempotent PlaySpotStore V27 update, works on V25 (without V26) or V26."""
from pathlib import Path
import re, shutil

ROOT=Path.cwd()
PART=ROOT/'playspot-v27'
BASE=330012
for lang,filename in [('ro','index.html'),('ru','ru.html')]:
    path=ROOT/filename
    if not path.is_file(): raise SystemExit('Missing '+filename)
    s=path.read_text(encoding='utf-8')
    for needed in ('</footer>', '</head>', '</body>'):
        if needed not in s: raise SystemExit(f'{filename}: missing {needed}')
    ru=lang=='ru'
    heading='Посетители · 2026' if ru else 'Vizitatori · 2026'
    hint='База 330 012 задана вручную; добавляются новые посещения' if ru else 'Bază 330.012 setată manual; se adaugă vizitele noi'
    alt='Общий счётчик с заданной начальной базой' if ru else 'Contor total cu bază inițială setată manual'
    note='База 330 012 · ожидание сервера' if ru else 'Bază 330.012 · așteptăm contorul'
    section=f'''
<!-- V27: 2026 preset is manual. Only future browser visits are measured by CountAPI. -->
<section class="p26-visitor-counter" id="p26-visitors" aria-label="{alt}">
  <div class="p26-inner">
    <span class="p26-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM21 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
    <div class="p26-copy"><strong>{heading}</strong><small>{hint}</small><small id="p27-status" aria-live="polite">{note}</small></div>
    <output class="p26-number" id="p26-total" aria-live="polite" aria-atomic="true" data-state="baseline">{'330 012' if ru else '330.012'}</output>
  </div>
</section>
'''
    if 'id="p26-visitors"' in s:
        old=re.search(r'(?:<!-- (?:PlaySpotStore V26|V27:)[^\n]*-->\s*)?<section class="p26-visitor-counter" id="p26-visitors"[\s\S]*?</section>',s)
        if old:
            s=s[:old.start()]+section.strip()+s[old.end():]
        else:
            raise SystemExit(filename+': existing counter markup unexpectedly different; not overwriting')
    else:
        s=s.replace('</footer>', '</footer>'+section,1)
    for old,new in [(r'playspot-v26\.css(?:\?[^"\s]*)?', 'playspot-v27.css?v=20261108-v27'),
                    (r'playspot-v26\.js(?:\?[^"\s]*)?', 'playspot-v27.js?v=20261108-v27')]:
        s=re.sub(old,new,s)
    css='<link rel="stylesheet" href="playspot-v27.css?v=20261108-v27">'
    script='<script defer src="playspot-v27.js?v=20261108-v27"></script>'
    if 'playspot-v27.css' not in s:s=s.replace('</head>', '  '+css+'\n</head>',1)
    if 'playspot-v27.js' not in s:s=s.replace('</body>', '  '+script+'\n</body>',1)
    if s.count('id="p26-visitors"')!=1 or s.count('id="p26-total"')!=1 or s.count('playspot-v27.js')!=1 or s.count('playspot-v27.css')!=1:
        raise SystemExit(filename+': unexpected duplicates; refusing change')
    path.write_text(s,encoding='utf-8')
    print('Patched',filename)
for ext in ('css','js'):
    shutil.copy2(PART/f'playspot-v27.{ext}', ROOT/f'playspot-v27.{ext}')
print('V27 assets installed; shared backend counter key preserved')
