#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$ROOT" ]]; then echo 'ERROR: Rulează în repository-ul Codespaces playspotstore.' >&2; exit 1; fi
cd "$ROOT"
if [[ "$(basename "$ROOT")" != "playspotstore" ]]; then echo 'ERROR: Nu ești în playspotstore.' >&2; exit 1; fi
if [[ "$(git branch --show-current)" != "main" ]]; then echo 'ERROR: Schimbă pe branch-ul main înainte de update.' >&2; exit 1; fi
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'ERROR: Există modificări locale netrimise. Salvează-le (commit/stash) înainte să continui.' >&2
  git status --short >&2; exit 1
fi
# Always pull before modifying website files.
git pull --ff-only origin main
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$HERE/playspot-v13.css" ./playspot-v13.css
cp "$HERE/playspot-v13.js" ./playspot-v13.js
python3 - <<'PYINSTALL'
from pathlib import Path
import re
TIKTOK_SVG = '''<svg class="p13-tiktok-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.8 3.5h-4.3v17a4.5 4.5 0 1 1-4-4.47v-4.3a8.8 8.8 0 1 0 8.3 8.77v-8.6a11.1 11.1 0 0 0 6.4 2v-4.3a6.6 6.6 0 0 1-6.4-6.1Z"/></svg>'''
TRUCK_SVG = '''<svg class="p13-awb-truck" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="Livrare" fill="none" stroke="currentColor" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h30v27H9V18Z"/><path d="M39 27h9l8 9v9H39V27Z"/><path d="M41 28v10h14"/><circle cx="20" cy="46" r="5.5" fill="#0b3333"/><circle cx="48" cy="46" r="5.5" fill="#0b3333"/><path d="M4 24h9M5 32h8M7 39h6"/></svg>'''
for lang,file in [('ro','index.html'),('ru','ru.html')]:
    path=Path(file); s=path.read_text(encoding='utf8')
    # Replace TikTok card completely — no dependence on previous version's HTML or icon font.
    card_re=r'<div\s+class="social-card[^"<>]*"\s*>\s*(?:(?!</div>).)*?<h3>\s*TikTok\s*</h3>(?:(?!</div>).)*?</div>'
    text=('Video-uri, oferte și noutăți!' if lang=='ro' else 'Видео, скидки и новинки!')
    btn=('Urmărește-ne' if lang=='ro' else 'Подписаться')
    card='''<div class="social-card p13-tiktok-card">
      '''+TIKTOK_SVG+'''
      <h3>TikTok</h3>
      <span class="p13-tiktok-handle">@playspotstore</span>
      <p>'''+text+'''</p>
      <a href="https://www.tiktok.com/@playspotstore/" target="_blank" rel="noopener noreferrer" class="btn">'''+btn+'''</a>
    </div>'''
    s,n=re.subn(card_re,lambda m:card,s,count=1,flags=re.S)
    if n!=1:raise RuntimeError(f'{file}: TikTok card not found exactly once')
    # Keep the numeric 03 and text. Replace only step-3 icon, whether old font glyph or SVG.
    a=s.index('data-modal="order-modal-step-3"'); b=s.index('<h3>',a)
    section=s[a:b]
    section,icon_count=re.subn(r'(?:<svg\b[^>]*>[\s\S]*?</svg>|<i\b[^>]*>\s*</i>)',TRUCK_SVG,section,count=1)
    if icon_count!=1:raise RuntimeError(f'{file}: step-3 icon not found')
    s=s[:a]+section+s[b:]
    # Append new CSS after all previous CSS, and JS at the end after prior scripts.
    s=re.sub(r'\s*<link\s+rel="stylesheet"\s+href="playspot-v13\.css[^"<>]*"\s*/?>','',s)
    s=re.sub(r'\s*<script\s+defer\s+src="playspot-v13\.js[^"<>]*"\s*>\s*</script>','',s)
    assert '</head>' in s and '</body>' in s
    s=re.sub(r'\s*</head>', '\n  <link rel="stylesheet" href="playspot-v13.css?v=20261107-2">\n</head>', s, count=1)
    p=s.rfind('</body>');s=s[:p].rstrip()+'\n  <script defer src="playspot-v13.js?v=20261107-2"></script>\n'+s[p:]
    assert s.count('playspot-v13.css')==1 and s.count('playspot-v13.js')==1
    assert s.count('class="social-card p13-tiktok-card"')==1
    assert s.count('p13-awb-truck')==1
    path.write_text(s,encoding='utf8')
    print('Updated',file)
PYINSTALL
if command -v node >/dev/null 2>&1; then node --check playspot-v13.js; fi
git add index.html ru.html playspot-v13.css playspot-v13.js
if git diff --cached --quiet; then echo 'V13 deja instalat, nimic de modificat.'; exit 0; fi
git commit -m 'Add WhatsApp Instagram order choice and fix TikTok and AWB icons'
git push origin main
echo 'SUCCESS: V13 publicat pe main. Reîncarcă site-ul cu hard refresh.'
