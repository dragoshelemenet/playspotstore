PLAYSPOTSTORE V21 — Minimal TikTok + Subtle Spin Pulse

Changes:
1. Removes explanatory paragraph under TikTok gallery title (RO/RU).
2. Removes the 01/05...05/05 badges from all TikTok cards (RO/RU).
3. Replaces campaign counter display with OFERTĂ LIMITATĂ / ОГРАНИЧЕННАЯ АКЦИЯ; no days/hours.
4. Leaves won-game expiry and the "Valabil până la" date in PNG/WhatsApp untouched.
5. Adds a very subtle 11-second pulse cycle, including a long still period; reduced-motion disables it.

Install in Codespaces root:
git pull --ff-only origin main && unzip -o playspotstore-v21-tiktok-spin-polish.zip -d . && bash playspot-v21/install.sh

No video or product data files are changed.
