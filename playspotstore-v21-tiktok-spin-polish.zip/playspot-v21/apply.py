#!/usr/bin/env python3
"""PlaySpotStore V21. Safe, idempotent targeted patch. Run in repository root."""
from pathlib import Path
import re

ROOT=Path.cwd()
V16=ROOT/'playspot-v16.js'
OLD_COUNTDOWN='countdown.textContent = data.remaining + words.unit;'
OLD_LABEL='label.textContent = words.label;'
OLD_A11Y="countdown.setAttribute('aria-label', words.label + ' ' + data.remaining + (isRu ? ' дней' : ' zile'));"
OLD_TITLE='countdown.title = endDate;'

# Preflight all source files before touching anything.
if not V16.is_file():raise SystemExit('ERROR: playspot-v16.js not found. Install V16/V20 first.')
src=V16.read_text(encoding='utf-8')
steps={
    OLD_COUNTDOWN: "countdown.textContent = isRu ? 'ОГРАНИЧЕННАЯ АКЦИЯ' : 'OFERTĂ LIMITATĂ';",
    OLD_LABEL: "label.textContent = '';",
    OLD_A11Y: "countdown.setAttribute('aria-label', countdown.textContent);",
    OLD_TITLE: "countdown.removeAttribute('title');",
}
for old,new in steps.items():
    if old not in src and new not in src:raise SystemExit('ERROR: Cannot locate expected v16.js fragment: '+old)
new_src=src
for old,new in steps.items():
    if old in new_src:
        if new_src.count(old)!=1:raise SystemExit('ERROR: Unexpected multiple v16.js fragments: '+old)
        new_src=new_src.replace(old,new)

pages=[]
phrases={
  'index.html':'5 clipuri din magazin. Apasă pe unul pentru a vedea videoclipul complet pe TikTok.',
  'ru.html':'5 видео из магазина. Нажми на карточку, чтобы посмотреть полное видео в TikTok.'
}
for filename,phrase in phrases.items():
    f=ROOT/filename
    if not f.is_file():raise SystemExit('ERROR: missing '+filename)
    s=f.read_text(encoding='utf-8')
    if 'id="p20-tiktok-gallery"' not in s:raise SystemExit('ERROR: V20 gallery missing in '+filename)
    if phrase in s:
        s=s.replace('<p>'+phrase+'</p>','')
    elif phrase.replace('5 ','') in s:raise SystemExit('ERROR: Unmatched helper text markup in '+filename)
    s,count=re.subn(r'\s*<span class="p20-number">\d{2}\s*<span>\s*/\s*05</span></span>','',s)
    if count not in (0,5):raise SystemExit(f'ERROR: Unexpected TikTok counter count {count} in {filename}')
    # Safety check: selectors should not remain in the gallery after patch.
    start=s.index('<section class="p20-tiktok-gallery"')
    end=s.index('</section>',start)
    gallery=s[start:end]
    if '<span class="p20-number"' in gallery or phrase in gallery:raise SystemExit('ERROR: stale badge or copy in '+filename)
    old_link='playspot-v16.js?v=20261108-v18'
    if old_link in s:s=s.replace(old_link,'playspot-v16.js?v=20261108-v21')
    elif 'playspot-v16.js?v=20261108-v21' not in s:
        # keep existing version suffix flexible: this is a cache bust, never a functional change.
        s,n=re.subn(r'playspot-v16\.js\?v=[^"\']+','playspot-v16.js?v=20261108-v21',s)
        if n!=1:raise SystemExit('ERROR: Cannot cache-bust v16.js in '+filename)
    if 'playspot-v21.css' not in s:
        if s.count('</head>')!=1:raise SystemExit('ERROR: malformed head in '+filename)
        s=s.replace('</head>','  <link rel="stylesheet" href="playspot-v21.css?v=20261108-v21">\n</head>')
    pages.append((f,s))
# Apply only after all validations have passed.
V16.write_text(new_src,encoding='utf-8')
for file,content in pages:file.write_text(content,encoding='utf-8')
(ROOT/'playspot-v21.css').write_bytes((Path(__file__).parent/'playspot-v21.css').read_bytes())
print('SUCCESS V21: TikTok copy/counters removed; limited-offer label and gentle pulse installed (RO/RU).')
