#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [ ! -f index.html ] || [ ! -f ru.html ]; then
  echo "ERROR: run from PlaySpotStore repository" >&2; exit 1
fi
git pull --ff-only origin main
python3 playspot-v21/apply.py
git add index.html ru.html playspot-v16.js playspot-v21.css
if git diff --cached --quiet; then
  echo "V21 is already installed."
  exit 0
fi
git commit -m "V21 simplify TikTok cards and add subtle Spin Win pulse"
git push origin HEAD:main
echo "SUCCESS: V21 pushed to main"
