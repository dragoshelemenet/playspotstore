#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != main ]]; then
  echo 'Please switch to main before running this installer.' >&2
  exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo 'Uncommitted changes found. Please commit or stash tracked changes before installing.' >&2
  git status --short
  exit 1
fi
printf '== PlaySpotStore V12: pull main first ==\n'
git pull --ff-only origin main
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/playspot-v12.css" playspot-v12.css
cp "$SCRIPT_DIR/playspot-v12.js" playspot-v12.js
python3 - <<'PY'
from pathlib import Path
import re

TIKTOK_SVG = '''<svg class="p12-tiktok-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" role="img" aria-label="TikTok"><path d="M16.7 2h-3.3v12.45a3.08 3.08 0 1 1-2.48-3.02V8.1a6.5 6.5 0 1 0 5.78 6.45V7.55A8.8 8.8 0 0 0 21 8.6V5.3A5.1 5.1 0 0 1 16.7 2Z"/></svg>'''
TRUCK_SVG = '''<svg class="p12-awb-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 7.5h11.2v9H2.5z"/><path d="M13.7 10h3.2l3.5 3.6v2.9h-2"/><path d="M2.5 16.5h2.2m5 0h6"/><circle cx="7.2" cy="17.1" r="1.9"/><circle cx="17.7" cy="17.1" r="1.9"/><path d="M1.5 5h8M1.5 8.9H1"/></svg>'''

for filename,ru in [('index.html',False),('ru.html',True)]:
    p=Path(filename)
    s=p.read_text(encoding='utf-8')
    # Replace only the actual TikTok card. This keeps every other contact card intact.
    if 'p12-tiktok-card' not in s:
        original='<div class="social-card">\n    <i class="bx bxl-tiktok"></i>'
        if s.count(original)!=1:
            raise RuntimeError(f'{filename}: TikTok card not found exactly once')
        s=s.replace(original,'<div class="social-card p12-tiktok-card">\n    '+TIKTOK_SVG,1)
    start=s.index('<div class="social-card p12-tiktok-card">')
    end=s.index('</div>',start)+len('</div>')
    card=s[start:end]
    card=re.sub(r'<h3>TikTok</h3>', '<h3>TikTok</h3>\n    <span class="p12-tiktok-handle">@playspotstore</span>',card,count=1) if 'p12-tiktok-handle' not in card else card
    card=re.sub(r'<p>.*?</p>', '<p>'+('Видео, акции и новинки!' if ru else 'Video-uri, oferte și noutăți!')+'</p>',card,count=1,flags=re.S)
    card,links=re.subn(r'<a\b[^>]*class="btn"[^>]*>[^<]*</a>', '<a href="https://www.tiktok.com/@playspotstore/" target="_blank" rel="noopener noreferrer" class="btn">'+('Подписаться' if ru else 'Urmărește-ne')+'</a>',card,count=1)
    if links!=1:raise RuntimeError(f'{filename}: TikTok button not found')
    s=s[:start]+card+s[end:]
    # Remove one fragile glyph; use self-contained AWB truck SVG.
    awb=re.compile(r'(<div class="step" data-modal="order-modal-step-3"[^>]*>\s*)<i class="bx bx-truck"></i>')
    s,count=awb.subn(lambda m:m.group(1)+TRUCK_SVG,s,count=1)
    if count==0 and 'p12-awb-icon' not in s and 'p11-awb-icon' not in s:
        raise RuntimeError(f'{filename}: AWB icon not found')
    # Expose pre-existing product-specific fallback images to the recovery layer.
    if 'data-p12-fallback' not in s:
        needle='img.setAttribute("data-src", game.image);'
        if s.count(needle)!=1:raise RuntimeError(f'{filename}: product image constructor changed')
        s=s.replace(needle,needle+'\n  if (game.fallback_image) img.setAttribute("data-p12-fallback", game.fallback_image);',1)
    style='<link rel="stylesheet" href="playspot-v12.css?v=20261106">'
    script='<script defer src="playspot-v12.js?v=20261106"></script>'
    if style not in s:s=s.replace('</head>','  '+style+'\n</head>',1)
    if script not in s:s=s.replace('</body>','  '+script+'\n</body>',1)
    assert s.count('https://www.tiktok.com/@playspotstore/')==1
    assert s.count('p12-tiktok-card')==1
    assert 'playspot-v12.css' in s and 'playspot-v12.js' in s
    p.write_text(s,encoding='utf-8')
    print(f'Updated {filename}: TikTok link/icon, AWB SVG, product art fallbacks')
PY

git add index.html ru.html playspot-v12.css playspot-v12.js
if git diff --cached --quiet; then
  echo 'V12 already installed. No changes needed.'
  exit 0
fi
git -c user.name='PlaySpotStore Updates' -c user.email='updates@users.noreply.github.com' commit -m 'Fix TikTok card and broken cover fallbacks'
git push origin main
printf '\nSUCCESS: PlaySpotStore V12 published to main.\n'
