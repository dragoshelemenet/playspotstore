#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != "main" ]]; then
  echo "ERROR: Switch to the main branch before installing (git switch main)." >&2
  exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "ERROR: You have uncommitted tracked changes. Commit or stash them first." >&2
  exit 1
fi
printf '\n=== PlaySpotStore V7: Mobile social buttons & product listings ===\n'
python3 - <<'PY'
from pathlib import Path
import re
css_src = Path('playspot-v7/playspot-v7.css')
if not css_src.exists():
    raise SystemExit('ERROR: Missing playspot-v7/playspot-v7.css. Please extract the complete ZIP.')
css = css_src.read_text(encoding='utf-8')
assert 'section.social-media' in css and 'grid-template-columns: repeat(2,' in css
for filename in ('index.html', 'ru.html'):
    page = Path(filename)
    html = page.read_text(encoding='utf-8')
    if html.lower().count('</head>') != 1:
        raise SystemExit('ERROR: Expected a single </head> in ' + filename)
    if 'neon-v5-fixes.css' not in html or 'playspot-v6.css' not in html:
        raise SystemExit('ERROR: ' + filename + ' appears to be missing V5/V6. Pull main before installing.')
    html = re.sub(r'(?m)^\s*<link\s+rel=["\']stylesheet["\']\s+href=["\']playspot-v7\.css[^"\']*["\']\s*/?>\s*\n?', '', html)
    link = '  <link rel="stylesheet" href="playspot-v7.css?v=20261105a">\n'
    html = html.replace('</head>', link + '</head>', 1)
    assert html.count('playspot-v7.css') == 1
    page.write_text(html, encoding='utf-8')
    print('Updated', filename)
Path('playspot-v7.css').write_text(css, encoding='utf-8')
print('Installed playspot-v7.css')
PY

git add index.html ru.html playspot-v7.css
if git diff --cached --quiet; then
  echo "Already installed. Nothing to commit."
else
  git diff --cached --check
  git commit -m "Fix mobile contact buttons and two-column product listings"
  git push origin main
fi
printf '\nSUCCESS: Mobile social buttons and product grids updated on main.\n'
