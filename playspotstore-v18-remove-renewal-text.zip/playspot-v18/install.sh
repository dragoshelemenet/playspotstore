#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
[[ -f index.html && -f ru.html && -f playspot-v16.js && -f playspot-v14.js ]] || { echo 'ERROR: Run in PlaySpotStore repository root with V16 installed.' >&2; exit 1; }
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'ERROR: Tracked changes exist. Commit or stash them before updating.' >&2
  git status --short
  exit 1
fi
git pull --ff-only origin main
python3 playspot-v18/install.py
if command -v node >/dev/null 2>&1; then
  node --check playspot-v16.js
  node --check playspot-v18.js
fi
git add index.html ru.html playspot-v16.js playspot-v18.css playspot-v18.js
if git diff --cached --quiet; then echo 'V18 already installed'; exit 0; fi
git -c user.name='PlaySpotStore' -c user.email='playspotstore@users.noreply.github.com' commit -m 'Remove promotional renewal notice from Spin and Win dialog'
git push origin HEAD:main
echo 'SUCCESS — V18 published. Refresh PlaySpotStore.'
