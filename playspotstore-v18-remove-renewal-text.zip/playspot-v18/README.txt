PlaySpotStore V18 — removes renewal notice from public Spin & Win popup.

1. Upload playspotstore-v18-remove-renewal-text.zip into repository root.
2. Run:
   git pull --ff-only origin main && unzip -o playspotstore-v18-remove-renewal-text.zip -d . && bash playspot-v18/install.sh

- Removes public paragraph describing the promotion's renewal entirely in RO and RU.
- Keeps bottom bar countdown, wheel, 3 spins/day, 30-day individual voucher expiration and PNG validity date.
- New CSS/JS versioned assets to defeat the stale-file browser cache and hide any legacy notice.
- Does not change other design or product data.
