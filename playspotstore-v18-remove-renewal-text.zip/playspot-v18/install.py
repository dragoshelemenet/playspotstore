#!/usr/bin/env python3
"""PlaySpotStore V18: remove all public auto-renewal copy from Spin & Win."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

def exact_replace(src, old, new, label):
    if old not in src:
        if new in src: return src
        raise RuntimeError(f"{label}: expected source not found, not changing file")
    if src.count(old) != 1: raise RuntimeError(f"{label}: ambiguous source")
    return src.replace(old, new, 1)

def fix_script():
    f = ROOT / 'playspot-v16.js'
    s = f.read_text(encoding='utf8')
    # No marketing copy about renewals (or campaign's own end) belongs in the prize modal.
    old = """  const note = document.createElement('p');
  note.className = 'p15-campaign-note';
  const terms = document.querySelector('#p14-spin-overlay .p14-terms');
  if (terms) terms.insertAdjacentElement('beforebegin', note);"""
    new = """  // Never insert a campaign renewal notice in the public Spin & Win dialog.
  document.querySelectorAll('#p14-spin-overlay .p15-campaign-note').forEach(node => node.remove());"""
    s = exact_replace(s, old, new, 'V16 modal note')
    s = exact_replace(s, '    note.textContent = words.note;', '    // The 30-day date is shown on each individual prize, not as a campaign notice.', 'V16 renewal text')
    s = s.replace("button: '-10% · Крути!',note: 'Акция ограничена по времени. Каждый полученный код действителен 30 дней с момента выигрыша.',", "button: '-10% · Крути!',")
    s = s.replace("button: 'Spin -10%',note: 'Promoție cu durată limitată. Fiecare cod câștigat este valabil 30 de zile de la rotire.',", "button: 'Spin -10%',")
    f.write_text(s, encoding='utf8')
    print('Fixed playspot-v16.js: no campaign note is generated')

def patch_html(name):
    f=ROOT/name
    s=f.read_text(encoding='utf8')
    s=exact_replace(s,'playspot-v16.js?v=20261108-v17','playspot-v16.js?v=20261108-v18','V16 cache '+name)
    css='<link rel="stylesheet" href="playspot-v18.css?v=20261108-fix1">'
    js='<script defer src="playspot-v18.js?v=20261108-fix1"></script>'
    if css not in s:
        if 'href="playspot-v16.css' not in s:raise RuntimeError('V16 stylesheet not found in '+name)
        s=s.replace('</head>', '  '+css+'\n</head>',1)
    if js not in s:
        if 'src="playspot-v16.js' not in s:raise RuntimeError('V16 JavaScript not found in '+name)
        s=s.replace('</body>', '  '+js+'\n</body>',1)
    f.write_text(s,encoding='utf8')
    print('Updated',name)

fix_script()
for name in ('index.html','ru.html'):patch_html(name)
for name in ('playspot-v18.css','playspot-v18.js'):
    source=Path(__file__).parent/name
    (ROOT/name).write_bytes(source.read_bytes())
print('SUCCESS: campaign renewal copy removed from modal on RO + RU; prize expiry remains untouched')
