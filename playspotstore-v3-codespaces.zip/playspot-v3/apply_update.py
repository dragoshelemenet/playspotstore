"""Idempotent PlaySpotStore V3 update. Run via Codespaces install.sh after git pull."""
from pathlib import Path
import sys,re,json,shutil,unicodedata
ROOT=Path(sys.argv[1]);PKG=Path(sys.argv[2]);
for f in ('index.html','ru.html','neon-redesign.css','neon-v2.css'):
 if not (ROOT/f).exists():raise SystemExit('Missing '+f+'; expected PlaySpotStore Neon V2 repository.')
if not (PKG/'inventory-additions.json').exists():raise SystemExit('Missing bundled inventory additions.')

# Normalize lookalike punctuation only for duplicate detection, not displayed titles.
def norm(s):
 s=unicodedata.normalize('NFKD',s).casefold().replace('’',"'").replace('–','-')
 s=''.join(c for c in s if not unicodedata.combining(c))
 return re.sub(r'[^a-z0-9]+',' ',s).strip()

addition=json.loads((PKG/'inventory-additions.json').read_text(encoding='utf-8'))
count_new=0;count_existing=0
for cat, products in addition.items():
 for lang in ('ro','ru'):
  path=ROOT/'data'/(cat+('_ru' if lang=='ru' else '')+'.json')
  existing=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
  existing_index={norm(x.get('title','')):x for x in existing}
  for prod in products:
   p=prod.copy();p.pop('condition',None);p.pop('photo_source',None)
   if lang=='ru':
    p['price']='Уточняйте при обращении'
    p['description']='Новое поступление. Уточняйте состояние, цену и наличие при обращении.'
   else:p['description']='Adăugat recent. Confirmă starea, prețul și disponibilitatea prin contact.'
   n=norm(p['title'])
   if n in existing_index:
    old=existing_index[n]
    old['new_arrival']='yes'
    # Do not overwrite existing manually maintained prices, images or descriptions.
    count_existing+=1
   else:
    existing.append(p);existing_index[n]=p;count_new+=1
  path.parent.mkdir(parents=True,exist_ok=True)
  path.write_text(json.dumps(existing,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(f'Catalog: {count_new//2} new product records + {count_existing//2} existing records marked as new arrivals.')

# Optional: if a dedicated new logo is placed in Codespace's repo root, use it in this update.
logo_ref='media/play-spot-logo.webp'
for filename in ('brand-logo.png','brand-logo.webp','brand-logo.jpg'):
 if (ROOT/filename).is_file():
  target='media/play-spot-custom-logo.'+filename.rsplit('.',1)[-1]
  (ROOT/'media').mkdir(exist_ok=True)
  shutil.copy2(ROOT/filename, ROOT/target)
  logo_ref=target
  print('Using user-uploaded logo:',filename)
  break
if logo_ref=='media/play-spot-logo.webp':
 print('Using supplied PlaySpot Store chrome wordmark cropped from gaming showcase.')

# Copy prepared assets. Keep existing photo folders, data and old neon assets intact.
shutil.copy2(PKG/'neon-v3.css',ROOT/'neon-v3.css')
for src in (PKG/'media').rglob('*'):
 if not src.is_file():continue
 dst=ROOT/src.relative_to(PKG)
 dst.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(src,dst)

for filename,ru in [('index.html',False),('ru.html',True)]:
 path=ROOT/filename;html=path.read_text(encoding='utf-8')
 # repair first updater's invalid extra head close, if still present
 if html.count('</head>')>1:
  html=html.replace('</head>', '',html.count('</head>')-1)
 if html.count('</head>')!=1:raise SystemExit('Unexpected HTML head in '+filename)
 css='<link rel="stylesheet" href="neon-v3.css?v=20261104-v3">'
 html=re.sub(r'<link\s+rel="stylesheet"\s+href="neon-v3\.css\?v=[^"]+"\s*/?>','',html)
 html=html.replace('</head>', '  '+css+'\n</head>',1)
 # Header: replace old inline controller icon with a crisp branded image.
 replacement='<header>\n<a class="logo" href="#acasa" aria-label="PlaySpotStore"><img class="brand-logo" src="'+logo_ref+'" alt="PlaySpot Store" width="240" height="65" decoding="async"></a>'
 html,found=re.subn(r'<header>\s*<a class="logo".*?</a>',replacement,html,count=1,flags=re.S)
 if found!=1:raise SystemExit('Expected PlaySpotStore header logo not found in '+filename)
 # Remove wrong currency added after price. The JSON already stores MDL / contact text.
 html=html.replace('p.textContent = (game.price || "") + " RON";',
                   'p.textContent = game.price || "'+('Уточняйте при обращении' if ru else 'Concretizează prin contact')+'";')
 html=html.replace('${g.price || ""} RON', '${g.price || "'+('Уточняйте при обращении' if ru else 'Concretizează prin contact')+'"}')
 html=html.replace('n.textContent = "New!";', 'n.textContent = "Produs nou";')
 # Use locally hosted image if a shop hotlink is blocked.
 html=html.replace('img.setAttribute("data-src", game.image);', 'img.setAttribute("data-src", game.image);\n  if (game.fallback_image) {\n    img.onerror = () => { if (!img.src.endsWith(game.fallback_image)) img.src = game.fallback_image; };\n  }')
 # Prevent the legacy fetch from duplicating existing nav items.
 html=html.replace('cats.forEach(cat => {\n      const li = document.createElement("li");',
                   'cats.forEach(cat => {\n      if (mainMenu.querySelector(`a[data-category-id="${cat.id}"]`)) return;\n      const li = document.createElement("li");')
 # New arrivals card grid should remain fast despite the expanded inventory.
 html=html.replace('arrivals.forEach(prod => {', 'arrivals.sort((a,b) => Number(String(b.id).includes("-new-")) - Number(String(a.id).includes("-new-"))).slice(0, 28).forEach(prod => {')
 # Search new catalogs in the existing search UI.
 search_cat=['ps4','ps5','consoles','accessories','ps2','nintendo','xbox']
 suffix='_ru' if ru else ''
 fetchers=',\n    '.join(f'fetch("data/{c}{suffix}.json").then(r=>r.ok?r.json():[]).catch(()=>[])' for c in search_cat)
 custom='''function fetchSearchResults(query) {
  return Promise.all([
    '''+fetchers+'''
  ]).then(groups=>groups.flat().filter(item=>item.title && item.title.toLowerCase().includes(query))).catch(()=>[]);
}

'''
 html,search_n=re.subn(r'function fetchSearchResults\(query\)\s*\{.*?\n\}\n\n(?=function showSuggestions)', custom,html,count=1,flags=re.S)
 if search_n!=1:raise SystemExit('Search function not found in '+filename)
 html=html.replace('if (r.id.startsWith("ps5")) cat = "ps5";',
   'if (r.id.startsWith("ps5")) cat = "ps5";\n      if (r.id.startsWith("ps2")) cat = "ps2";\n      if (r.id.startsWith("nintendo")) cat = "nintendo";\n      if (r.id.startsWith("xbox")) cat = "xbox";')
 # User's gallery/photos: genuine uploaded images, optimized local files, no broken Google hotlinks.
 labels= [('inventory-214526.webp','PS5 · Aventură / Acțiune'),('inventory-214523.webp','PS5 · Multiplayer'),('inventory-214520.webp','PS4 · Colecție'),('inventory-214518.webp','PS4 · Alte jocuri'),('inventory-214426.webp','Nintendo / Xbox'),('inventory-214336.webp','Colecție PS2'),('vr2-stock.webp','PlayStation VR2')]
 if ru:labels=[(a, {'PS5 · Aventură / Acțiune':'PS5 · Приключения','PS5 · Multiplayer':'PS5 · Экшен','PS4 · Colecție':'PS4 · Коллекция','PS4 · Alte jocuri':'PS4 · Игры','Nintendo / Xbox':'Nintendo / Xbox','Colecție PS2':'Коллекция PS2','PlayStation VR2':'PlayStation VR2'}[b]) for a,b in labels]
 gallery=''.join(f'<figure><img src="media/gallery/{file}" loading="lazy" decoding="async" alt="{label}"><figcaption>{label}</figcaption></figure>' for file,label in labels)
 if ru:
  gta_title='Grand Theft Auto <em>VI</em>';gta_sub='Предзаказ по запросу';gta_body='Хотите заказать GTA VI? Уточните цену, версию и возможность оформления заказа через WhatsApp или Instagram. Наличие и сроки подтверждаются перед оплатой.';gta_button='Уточнить возможность заказа';gallery_title='Новые поступления';gallery_sub='Реальные фотографии товаров. Уточняйте наличие и состояние перед заказом.';vr_title='PlayStation <em>VR2</em>';vr_sub='Видеообзор';vr_body='Посмотрите короткое видео PlayStation VR2 и уточните комплектацию, состояние и наличие у PlaySpotStore.';contact='Связаться';all_new='Игры PS5';ps2='Игры PS2';nintendo='Nintendo';xbox='Xbox';need='Уточняйте цену и наличие';alt='PlaySpotStore: GTA VI — заказ по запросу'
 else:
  gta_title='Grand Theft Auto <em>VI</em>';gta_sub='COMENZI LA CERERE';gta_body='Vrei să comanzi GTA 6? Contactează-ne pentru a verifica posibilitatea de precomandă, ediția, prețul și disponibilitatea. Nu confirmăm o comandă până nu primești răspuns de la noi.';gta_button='Întreabă despre GTA 6';gallery_title='Produse adăugate recent';gallery_sub='Fotografii reale ale jocurilor și accesoriilor. Confirmă starea, prețul și disponibilitatea prin contact.';vr_title='PlayStation <em>VR2</em>';vr_sub='PREZENTARE VIDEO';vr_body='Vezi consola VR2 și accesoriile în video, apoi scrie-ne pentru a confirma ce conține pachetul, starea și disponibilitatea.';contact='Contactează-ne';all_new='Jocuri PS5';ps2='Jocuri PS2';nintendo='Nintendo';xbox='Xbox';need='Preț și disponibilitate prin contact';alt='PlaySpotStore: GTA 6 — posibilitate de comandă'
 wa_msg=('%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5%2C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D1%83%D0%B5%D1%82%20GTA%206' if ru else 'Salut%21%20Vreau%20sa%20aflu%20daca%20pot%20comanda%20GTA%206')
 # Official launch and platform information is time-sensitive, so do not hard-code a date or promise stock.
 section=f'''\n<!-- PlaySpot V3: verified-stock request, user photographs, and their VR2 footage -->
<section class="p3-collection" id="produse-noi"><div>
  <div class="p3-collection-heading"><div><span class="p3-label">{need}</span><h2>{gallery_title}</h2><p>{gallery_sub}</p></div></div>
  <div class="p3-photo-grid">{gallery}</div>
  <div class="p3-links"><button type="button" onclick="openCategoryModal('ps5')">{all_new}</button><button type="button" onclick="showPlatformNotice('ps2')">{ps2}</button><button type="button" onclick="showPlatformNotice('nintendo')">{nintendo}</button><button type="button" onclick="showPlatformNotice('xbox')">{xbox}</button></div>
</div></section>
<section class="p3-launch" id="gta6"><div class="p3-inner">
  <div class="p3-copy"><span class="p3-label">{gta_sub}</span><h2>{gta_title}</h2><p>{gta_body}</p>
  <div class="p3-actions"><a class="p3-btn" href="https://wa.me/37378890580?text={wa_msg}" target="_blank" rel="noopener noreferrer">{gta_button}</a><a class="p3-btn secondary" href="https://www.instagram.com/PlaySpotStore" target="_blank" rel="noopener noreferrer">Instagram</a></div></div>
  <img class="p3-art" src="media/gta-vi-showcase.webp" loading="lazy" alt="{alt}" width="1000" height="550"></div></section>
<section class="p3-film" id="psvr2-video"><div class="p3-inner">
  <div class="p3-video-wrap"><video controls preload="none" playsinline poster="media/vr2-poster.webp" aria-label="PlayStation VR2 video"><source src="media/psvr2-showcase.mp4" type="video/mp4">{vr_title}</video></div>
  <div class="p3-copy"><span class="p3-label">{vr_sub}</span><h2>{vr_title}</h2><p>{vr_body}</p><div class="p3-actions"><a class="p3-btn" href="https://www.instagram.com/PlaySpotStore" target="_blank" rel="noopener noreferrer">{contact}</a></div></div>
</div></section>\n'''
 if '<section class="p3-collection"' not in html:
  anchor='<section class="social-media">'
  if anchor not in html:raise SystemExit('Social section anchor not found in '+filename)
  html=html.replace(anchor,section+anchor,1)
 # make category choices accessible; preserve existing modal JS and callbacks.
 js='''\n<script id="p3-catalogue">\n(function(){
  const isRu = document.documentElement.lang.toLowerCase().startsWith('ru');
  const suffix = isRu ? '_ru' : '';
  const categories = ['ps2','nintendo','xbox'];
  const originalOpenGame = window.openGame;
  window.openGame = function(id,cat){
    if(!categories.includes(cat)) return originalOpenGame(id,cat);
    fetch('data/'+cat+suffix+'.json').then(r=>r.ok?r.json():[]).then(data=>{
      const game=data.find(item=>String(item.id)===String(id));
      if(game) window.showGameModal(game);
    }).catch(console.error);
  };
  function closePlatform(modal){
    modal.remove();
    if(!document.querySelector('.modal.active')) document.body.style.overflow='';
  }
  window.showPlatformNotice=function(platform){
    if(!categories.includes(platform)) return;
    document.getElementById('p3-platform-dialog')?.remove();
    const modal=document.createElement('div');
    modal.id='p3-platform-dialog';modal.className='modal active p3-modal';
    modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');
    const content=document.createElement('div');content.className='modal-content';
    const close=document.createElement('button');close.className='close';close.type='button';close.textContent='×';close.setAttribute('aria-label',isRu?'Закрыть':'Închide');
    const title=document.createElement('h2');title.textContent=platform.toUpperCase()+(platform==='ps2'?' • PlayStation 2':'');
    const description=document.createElement('p');description.textContent=isRu?'Цена и наличие уточняются при обращении.':'Preț și disponibilitate prin contact.';
    const products=document.createElement('div');products.className='modal-products';
    content.append(close,title,description,products);modal.append(content);document.body.append(modal);
    close.onclick=()=>closePlatform(modal);
    modal.addEventListener('click',event=>{if(event.target===modal)closePlatform(modal);});
    modal.addEventListener('keydown',event=>{if(event.key==='Escape')closePlatform(modal);});
    document.body.style.overflow='hidden';close.focus();
    fetch('data/'+platform+suffix+'.json').then(r=>r.ok?r.json():[]).then(items=>{
      if(!items.length){products.textContent=isRu?'Сейчас нет товаров в каталоге.':'Momentan nu sunt produse în catalog.';return;}
      items.forEach(item=>products.appendChild(createProductCard(item,platform)));
      initLazyLoad();
    }).catch(()=>{products.textContent=isRu?'Ошибка загрузки каталога.':'Eroare la încărcarea catalogului.';});
  };
})();
</script>\n'''
 if 'id="p3-catalogue"' not in html:
  html=html.replace('</body>',js+'</body>',1)
 path.write_text(html,encoding='utf-8')
 print('Updated',filename)
print('Done. Product catalog will use local uploaded cover photos with verified online images where available.')
