#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
case "$(git remote get-url origin 2>/dev/null || true)" in *dragoshelemenet/playspotstore*) ;; *) echo 'Wrong repository. Open the playspotstore Codespace first.';exit 1;; esac
if [ "$(git branch --show-current)" != main ]; then echo 'Please switch to the main branch first: git switch main';exit 1;fi
# Always pull before modifying the repository, as requested.
echo 'Pulling the latest GitHub main...'
git pull --ff-only origin main
if [ -n "$(git status --porcelain --untracked-files=no)" ];then echo 'Tracked changes are present; commit or stash them before running this update.';git status --short;exit 1;fi
ROOT="$PWD";PAYLOAD="$ROOT/playspot-v3";test -f "$PAYLOAD/apply_update.py" || { echo "Cannot find $PAYLOAD/apply_update.py";exit 1; }
python3 "$PAYLOAD/apply_update.py" "$ROOT" "$PAYLOAD"
echo 'Files to be committed:'
git status --short
# Only stage files intentionally maintained by this update.
git add index.html ru.html neon-v3.css data media
if git diff --cached --quiet;then echo 'Already up to date; no changes to commit.';exit 0;fi
git -c user.name='PlaySpotStore Catalog Update' -c user.email='playspotstore-update@users.noreply.github.com' commit -m 'Upgrade storefront navigation, add VR2 video and 2026 game catalog'
echo 'Pushing to GitHub main...'
if git push origin main; then echo 'SUCCESS: new products, photos, logo, video and menu deployed to main.';else echo 'Changes committed locally. Run git push origin main after GitHub authentication.';exit 1;fi
