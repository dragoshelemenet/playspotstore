PLAYSPOTSTORE V16

Features:
- Campaign is permanent; timer shows remaining whole days in recurring 30-day windows, no hours.
- Existing 30-day cycle anchor preserved from spin-campaign.json.
- After day 30, countdown restarts at 30 days automatically.
- Every winning code expires 30 days after that particular game was won.
- Prize code validity/date shown in wheel, PNG, and WhatsApp.
- Previous same-day prizes lacking an expiresAt are assigned an approximate expiration 30 days after their win date.
- 3 spins per day per browser stays unchanged (not secure anti-fraud).

Upload this ZIP to repository root in Codespaces and run:
 git pull --ff-only origin main && unzip -o playspotstore-v16-renewing-spin.zip -d . && bash playspot-v16/install.sh
