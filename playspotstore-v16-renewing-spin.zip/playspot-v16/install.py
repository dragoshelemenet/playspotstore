#!/usr/bin/env python3
"""V16: perpetual 30-day promotion windows + 30-day expiry for each prize."""
from pathlib import Path
import json,re,shutil

ROOT=Path.cwd()
HERE=Path(__file__).resolve().parent
paths=[ROOT/'index.html', ROOT/'ru.html']
wheel=ROOT/'playspot-v14.js'
configpath=ROOT/'spin-campaign.json'
for p in [*paths,wheel,configpath]:
    if not p.exists():raise SystemExit(f'ERROR: Missing {p.name}; run from the playspotstore repo root.')
config=json.loads(configpath.read_text(encoding='utf-8'))
anchor=config.get('start_at')
if not anchor or not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d[+-]\d\d:\d\d',anchor):
    raise SystemExit('ERROR: spin-campaign.json start_at is missing or invalid.')

def replace(s,before,after,label):
    count=s.count(before)
    if count!=1:raise SystemExit(f'ERROR: Expected one {label}, found {count}; installation stopped safely.')
    return s.replace(before,after,1)

v14=wheel.read_text(encoding='utf-8')
if 'const p15CampaignExpired' in v14:
    v14=re.sub(r"  const p15ExpiresAt = Date\.parse\('[^']+'\);\n  const p15CampaignExpired = \(\) => Date\.now\(\) >= p15ExpiresAt;\n  const p15ExpiryLabel = new Intl\.DateTimeFormat\(ru \? 'ru-RU' : 'ro-RO',\{timeZone:'Europe/Chisinau', day:'numeric',month:'long',year:'numeric'\}\)\.format\(p15ExpiresAt\);\n",'',v14,count=1)
    if 'const p15CampaignExpired' in v14:raise SystemExit('ERROR: Could not remove fixed campaign deadline.')
    v14=replace(v14,'spinBtn.disabled=spinning || left===0 || !pool || p15CampaignExpired();','spinBtn.disabled=spinning || left===0 || !pool;','daily limit')
    v14=replace(v14,"if(p15CampaignExpired())status.textContent=ru?'Акция завершилась.':'Campania a expirat.';\n    else if(left===0 && !spinning)status.textContent=t.complete;",'if(left===0 && !spinning)status.textContent=t.complete;','expired status')
    v14=replace(v14,'  const open=()=>{\n    if(p15CampaignExpired())return;','  const open=()=>{','expired open guard')
    v14=replace(v14,"if(spinning || p15CampaignExpired())return;",'if(spinning)return;','expired spin guard')
    v14=replace(v14,"    if(p15CampaignExpired()){refreshCounter();return;}\n",'', 'expired secondary spin guard')
else:
    if 'p15ExpiresAt' in v14:raise SystemExit('ERROR: Unknown expiry rule; refusing unsafe edit')

if 'const prizeExpiryTime=' not in v14:
    insertion="""  const prizeMs=30*24*60*60*1000;
  const prizeExpiryTime=(win)=>{
    const explicit=Date.parse(win.expiresAt||'');if(Number.isFinite(explicit))return explicit;
    const historic=Date.parse(String(win.date||'')+'T12:00:00Z');
    return Number.isFinite(historic)?historic+prizeMs:Date.now()+prizeMs;
  };
  const printDate=(millis)=>new Intl.DateTimeFormat(ru?'ru-RU':'ro-RO',{
    timeZone:'Europe/Chisinau',day:'numeric',month:'long',year:'numeric'
  }).format(new Date(millis));
  const prizeValidity=(win)=>{
    const expires=prizeExpiryTime(win);
    return Date.now()>=expires ? (ru?'Код просрочен':'Cod expirat') :
      (ru?'Код действителен 30 дней, до ':'Cod valabil 30 zile, până la ')+printDate(expires);
  };
"""
    v14=replace(v14,'  const showResult=(win)=>{',insertion+'  const showResult=(win)=>{','prize expiry helpers')
    original="codeEl.textContent=win.code;claim.href='https://wa.me/'+cashPhone+'?text='+encodeURIComponent(t.message(win)+(ru?' Срок акции: до ':' Campanie valabilă până la ')+p15ExpiryLabel+'.');"
    revised="""codeEl.textContent=win.code;
    let validityEl=result.querySelector('.p14-win-validity');
    if(!validityEl){validityEl=document.createElement('p');validityEl.className='p14-win-validity';codeEl.insertAdjacentElement('afterend',validityEl);}
    validityEl.textContent=prizeValidity(win);
    if(Date.now()>=prizeExpiryTime(win)){
      claim.removeAttribute('href');claim.setAttribute('aria-disabled','true');
    }else{
      claim.removeAttribute('aria-disabled');
      claim.href='https://wa.me/'+cashPhone+'?text='+encodeURIComponent(t.message(win)+' '+
        (ru?'Код действует 30 дней, до ':'Codul este valabil 30 de zile, până la ')+printDate(prizeExpiryTime(win))+'.');
    }"""
    v14=replace(v14,original,revised,'WhatsApp expiry is per prize')
    orig="const win={id:game.id,platform:game.platform,title:game.title,price:game.price,date:dateParts(),dateLabel:prettyDate(),code:codeFor()};"
    new="const wonAt=Date.now();\n    const win={id:game.id,platform:game.platform,title:game.title,price:game.price,date:dateParts(),dateLabel:prettyDate(),code:codeFor(),wonAt:new Date(wonAt).toISOString(),expiresAt:new Date(wonAt+prizeMs).toISOString()};"
    v14=replace(v14,orig,new,'new prize 30-day expiration')
    v14=replace(v14,"c.fillText(t.receiptCondition,95,565);\n    c.font='600 20px Arial';c.fillText(t.receiptFooter+' · '+p15ExpiryLabel,95,596);",
        "c.fillText((ru?'Код действует до: ':'Cod valabil până la: ')+printDate(prizeExpiryTime(win)),95,548);\n    c.font='500 20px Arial';c.fillText(t.receiptCondition,95,576);\n    c.font='600 20px Arial';c.fillText(t.receiptFooter,95,605);",'PNG proof expiration')
else:
    if 'p15ExpiryLabel' in v14:raise SystemExit('ERROR: V14 still includes fixed campaign expiry')

new_pages={}
for p in paths:
    html=p.read_text(encoding='utf-8')
    html,n=re.subn(r'playspot-v14\.js\?v=[^"\']+','playspot-v14.js?v=20261108-v16',html,count=1)
    if n!=1:raise SystemExit(f'ERROR: expected V14 script in {p.name}')
    if 'playspot-v16.js?' not in html:
        html,n=re.subn(r'playspot-v15\.js\?v=[^"\']+','playspot-v16.js?v=20261108-v16',html,count=1)
        if n!=1:raise SystemExit(f'ERROR: expected V15 script in {p.name}')
    if 'playspot-v16.css?' not in html:
        html=replace(html,'</head>', '  <link rel="stylesheet" href="playspot-v16.css?v=20261108-v16">\n</head>',p.name+' CSS link')
    new_pages[p]=html

js=(HERE/'playspot-v16.js').read_text(encoding='utf-8')
js=replace(js,'__CAMPAIGN_START__',anchor,'original cycle start anchor')
config.pop('expires_at',None)
config['initial_cycle_start_at']=anchor
config['auto_renews']=True
config['renew_every_days']=30
config['prize_validity_days']=30
config['note']='Promotion renews automatically in 30-day cycles. Each prize expires 30 days after win. 3 spins/day are enforced only per browser; validate prize manually.'
# Write only after validating every anchor and transformation.
wheel.write_text(v14,encoding='utf-8')
for p,html in new_pages.items():p.write_text(html,encoding='utf-8')
(ROOT/'playspot-v16.js').write_text(js,encoding='utf-8')
shutil.copyfile(HERE/'playspot-v16.css',ROOT/'playspot-v16.css')
configpath.write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('V16 installed. Promotion now auto-renews every 30 days. Each prize expires 30 days after win.')
