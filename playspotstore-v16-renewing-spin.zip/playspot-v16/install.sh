#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
[[ -f index.html && -f ru.html && -f playspot-v14.js ]] || { echo 'ERROR: Run from playspotstore repo root.' >&2; exit 1; }
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'ERROR: Tracked files have uncommitted changes. Commit or stash before updating.' >&2
  git status --short
  exit 1
fi
python3 playspot-v16/install.py
if command -v node >/dev/null 2>&1; then node --check playspot-v14.js && node --check playspot-v16.js; fi
git add index.html ru.html playspot-v14.js playspot-v16.js playspot-v16.css spin-campaign.json
if git diff --cached --quiet; then echo 'V16 already installed.'; exit 0; fi
git -c user.name="PlaySpotStore" -c user.email="playspotstore@users.noreply.github.com" commit -m "Auto-renew 30-day Spin campaign and expire individual prizes"
git push origin HEAD:main
echo 'SUCCESS — PlaySpotStore V16 published to main.'
