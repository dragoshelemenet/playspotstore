#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then echo "ERROR: Run inside GitHub Codespaces repo" >&2; exit 1; fi
if [ ! -f index.html ] || [ ! -f ru.html ]; then echo "ERROR: index.html and ru.html missing" >&2; exit 1; fi
if [ "$(git branch --show-current)" != "main" ]; then echo "ERROR: Switch to main before installing" >&2; exit 1; fi
git pull --ff-only origin main
python3 playspot-v19/apply.py
git add index.html ru.html playspot-v19.css playspot-v19.js
if git diff --cached --quiet; then echo "No changes to commit (V19 already installed)."; else
  git commit -m "Add TikTok creator recent videos under social cards"
  git push origin main
fi
echo "SUCCESS: TikTok V19 section installed. Visit the page below the social-media cards."
