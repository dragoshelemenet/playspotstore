PlaySpotStore V19 - OFFICIAL TikTok recent-videos section

- Shows the TikTok Creator Profile Embed (real recent public videos) immediately below the social-media cards in RO and RU.
- TikTok controls the number/layout of its native recent-video carousel (it can show up to 10). An EXACT five-across layout requires an authenticated TikTok Display API and a backend to fetch the five latest, or five manually provided video links. This package intentionally never fabricates video IDs.
- Includes "Vezi mai multe pe TikTok" -> https://www.tiktok.com/@playspotstore/
- Lazy loads only near viewport, with readable fallback link if the embed is blocked.
- No changes to products, checkout, roulette, translations, campaign or other sections.

Codespaces (upload ZIP in repository root):
git pull --ff-only origin main && unzip -o playspotstore-v19-tiktok-feed.zip -d . && bash playspot-v19/install.sh

Note: Public TikTok creator embeds require that the account is public and can be blocked by TikTok, adblockers or browser privacy settings. No TikTok developer tokens are needed for the official profile embed. The site does not have access to a list of specific individual video IDs in this mode.
