#!/usr/bin/env python3
"""Install native TikTok creator video carousel directly below PlaySpotStore social cards.
Idempotent and safe to run after git pull, for index.html & ru.html.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
TAG = 'id="p19-tiktok-feed"'

def update(path):
    text = path.read_text(encoding='utf-8')
    if TAG not in text:
        start = text.find('<section class="social-media">')
        if start == -1:
            raise SystemExit(f'{path.name}: social-media section not found; nothing modified.')
        end = text.find('</section>', start)
        if end == -1:
            raise SystemExit(f'{path.name}: social-media closing tag not found; nothing modified.')
        end += len('</section>')
        html = (Path(__file__).parent / ('tiktok-ru.html' if path.name == 'ru.html' else 'tiktok-ro.html')).read_text(encoding='utf-8')
        text = text[:end] + '\n' + html + text[end:]
    css='<link rel="stylesheet" href="playspot-v19.css?v=20261108-tiktok19">'
    js='<script defer src="playspot-v19.js?v=20261108-tiktok19"></script>'
    if 'playspot-v19.css' not in text:
        if '</head>' not in text:
            raise SystemExit(f'{path.name}: </head> missing.')
        text=text.replace('</head>',f'  {css}\n</head>',1)
    if 'playspot-v19.js' not in text:
        if '</body>' not in text:
            raise SystemExit(f'{path.name}: </body> missing.')
        text=text.replace('</body>',f'  {js}\n</body>',1)
    path.write_text(text,encoding='utf-8')
    print(f'Updated {path.name}: TikTok recent-videos section ready')

for filename in ['index.html','ru.html']:
    path=ROOT/filename
    if not path.exists(): raise SystemExit(f'Run from PlaySpotStore repository root: {filename} missing.')
    update(path)
