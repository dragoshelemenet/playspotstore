#!/usr/bin/env python3
"""Install final V9 design stylesheet into the two existing V8 storefronts."""
from pathlib import Path
import re

root = Path.cwd()
link = '<link rel="stylesheet" href="playspot-v9.css?v=20261105p">'
updated = {}
for name in ('index.html', 'ru.html'):
    p = root / name
    if not p.is_file():
        raise SystemExit(f'Missing {name}. Run from the playspotstore repository.')
    data = p.read_text(encoding='utf-8')
    if data.count('</head>') != 1 or data.count('</body>') != 1:
        raise SystemExit(f'Unexpected HTML structure in {name}; no files changed.')
    if 'class="p8-footer"' not in data or 'playspot-v8.css' not in data:
        raise SystemExit(f'V8 footer not found in {name}. Pull main first; no files changed.')
    if 'playspot-v9.css' not in data:
        data = data.replace('</head>', f'  {link}\n</head>', 1)
    if len(re.findall(r'playspot-v9\.css', data)) != 1:
        raise SystemExit(f'Duplicate V9 stylesheet in {name}; no files changed.')
    updated[p] = data

for p, data in updated.items():
    if p.read_text(encoding='utf-8') != data:
        p.write_text(data, encoding='utf-8')
        print(f'Updated {p.name} — V9 design polish')
    else:
        print(f'{p.name} already uses V9 CSS')
