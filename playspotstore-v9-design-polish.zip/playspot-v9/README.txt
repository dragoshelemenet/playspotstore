PlaySpotStore V9: premium layout and spacing polish.

1. Upload playspotstore-v9-design-polish.zip to your Codespaces repository root.
2. In Codespaces Terminal run:

   git pull --ff-only origin main && unzip -o playspotstore-v9-design-polish.zip -d . && bash playspot-v9/install.sh

Changes: one additive CSS layer installed last on index.html and ru.html.
Preserves product JSON, existing image URLs, videos, nav/menu, order flow,
contact links, lightbox, tags dialog, V7 2/3/4-column grid, and V8 footer structure.

The installer performs another git pull before applying the changes, then
commits only index.html, ru.html and playspot-v9.css to main.
