#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
printf '\n=== PLAYSPOTSTORE V9 — VISUAL POLISH ===\n'
if [[ "$(git branch --show-current)" != main ]]; then
  echo 'Expected main branch. Switch first: git switch main' >&2
  exit 1
fi
if ! git diff --quiet HEAD -- index.html ru.html playspot-v9.css; then
  echo 'You have local edits to the website files. Commit or stash those before installing.' >&2
  exit 1
fi
if [[ ! -f 'playspot-v9/playspot-v9.css' || ! -f 'playspot-v9/apply.py' ]]; then
  echo 'Missing extracted installer. Unzip the V9 file into the repository root first.' >&2
  exit 1
fi
# Always synchronize before touching the website, including when run directly.
printf 'Pulling the latest main (fast-forward only)...\n'
git pull --ff-only origin main
python3 playspot-v9/apply.py
cp playspot-v9/playspot-v9.css playspot-v9.css
# Stage ONLY the three intended website files; never push zip, installer or user's other files.
git add -- index.html ru.html playspot-v9.css
if git diff --cached --quiet -- index.html ru.html playspot-v9.css; then
  echo 'Already up to date. No commit needed.'
  exit 0
fi
git commit -m 'Design: refine visual spacing and premium neon details' -- index.html ru.html playspot-v9.css
git push origin main
printf '\nSUCCESS: PlaySpotStore V9 published to GitHub main.\n'
